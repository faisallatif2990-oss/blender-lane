# -*- coding: utf-8 -*-
"""Practice-lab common machinery — History Vault 360, 2026-11-15.
Upgrades over the production builder (2026-11-15-knowledge/build_knowledge.py):
  * supersampled plate rendering (plate pre-upscaled x3, LANCZOS) = the PIL
    equivalent of the ffmpeg zoompan 4x-overscale anti-jitter rule
  * EASED motion (easeInOutCubic / easeOutCubic / easeOutQuint) instead of the
    builder's linear zoom; punch-ins as cumulative eased steps
  * grade v2: per-channel curves LUT (mild S-curve) + teal/amber split tone
  * character-weighted caption timing (craft upgrade #4)
  * animated counters, draw-on markup, type-on labels (12 fps stepped)
"""
import math, os, subprocess, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance

W, H, FPS = 1080, 1920, 24
SR = 44100
KNOW = os.path.expanduser("~/workspace/history-vault/production/2026-11-15-knowledge")
PLATES = os.path.join(KNOW, "plates")
VO_DIR = os.path.join(KNOW, "work_video1", "vo")
_HOUSE = os.path.dirname(os.path.abspath(__file__))
def _font(name): return os.path.join(_HOUSE, "fonts", name)
LAT = _font("NotoSans-Black.ttf")
GOLD = (255, 205, 40); GOLD2 = (232, 182, 76); WHITE = (255, 255, 255)
AMBER = (255, 176, 66); TEAL = (64, 178, 178)

def run(cmd, **kw):
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True, **kw)
    if r.returncode != 0:
        print("FAILED:", cmd[:200]); print(r.stderr[-1500:]); sys.exit(1)
    return r

from functools import lru_cache
@lru_cache(maxsize=None)
def F(size): return ImageFont.truetype(LAT, size)
@lru_cache(maxsize=None)
def FB(size): return ImageFont.truetype(_font("NotoSans-Bold.ttf"), size)
@lru_cache(maxsize=None)
def FS(size): return ImageFont.truetype(_font("DejaVuSerif.ttf"), size)
@lru_cache(maxsize=None)
def FSB(size): return ImageFont.truetype(_font("DejaVuSerif-Bold.ttf"), size)
@lru_cache(maxsize=None)
def FM(size): return ImageFont.truetype(_font("DejaVuSansMono.ttf"), size)
@lru_cache(maxsize=None)
def FMB(size): return ImageFont.truetype(_font("DejaVuSansMono-Bold.ttf"), size)

def tw(d, t, f, sw=0):
    bb = d.textbbox((0, 0), t, font=f, stroke_width=sw); return bb[2] - bb[0], bb

def ctext(d, cx, y, t, f, fill, sw=8):
    w, bb = tw(d, t, f, sw)
    d.text((cx - w / 2 - bb[0], y), t, font=f, fill=fill, stroke_width=sw, stroke_fill=(0, 0, 0, 235))
    return int(f.size * 1.28)

# ---------------- easing ----------------
def ease_inout(p):
    p = min(max(p, 0.0), 1.0)
    return 4 * p ** 3 if p < 0.5 else 1 - ((-2 * p + 2) ** 3) / 2
def ease_out(p):
    p = min(max(p, 0.0), 1.0); return 1 - (1 - p) ** 3
def ease_out_quint(p):
    p = min(max(p, 0.0), 1.0); return 1 - (1 - p) ** 5

# ---------------- grade v2 (curves + split tone as per-channel LUTs) ----------------
def _grade_luts():
    t = np.linspace(0, 1, 256)
    s = t + 0.35 * 4 * (t * (1 - t) * (t - 0.5))          # mild S-curve
    sh = (1 - t) ** 2; hi = t ** 2                          # shadow / highlight weights
    r = s + (-14 * sh + 13 * hi) / 255.0                    # shadows -red (teal), highlights +red (amber)
    g = s + (6 * sh + 5 * hi) / 255.0
    b = s + (15 * sh - 12 * hi) / 255.0                     # shadows +blue (teal), highlights -blue (amber)
    lut = []
    for ch in (r, g, b):
        lut += [int(min(max(v, 0), 1) * 255) for v in ch]
    return lut
_GRADE_LUT = _grade_luts()

def grade_v2(img):
    return img.point(_GRADE_LUT)

def grade_old(img):
    """The production builder's current grade, for A/B comparison."""
    im = ImageEnhance.Contrast(img).enhance(1.06)
    im = ImageEnhance.Brightness(im).enhance(0.995)
    r, g, b = im.split()
    r = r.point(lambda v: min(255, int(v * 1.03)))
    b = b.point(lambda v: int(v * 0.97))
    return Image.merge("RGB", (r, g, b))

# ---------------- plates: supersampled, graded once, cached ----------------
SS = 3
_plate_cache = {}
def get_plate(name, grade="v2"):
    key = (name, grade)
    if key in _plate_cache: return _plate_cache[key]
    im = Image.open(os.path.join(PLATES, name + ".jpg")).convert("RGB")
    im = grade_v2(im) if grade == "v2" else grade_old(im)
    im = im.resize((im.width * SS, im.height * SS), Image.LANCZOS)
    _plate_cache[key] = im
    return im

_VIG = None
def vignette(img):
    global _VIG
    if _VIG is None:
        ov = Image.new("L", (W, H), 0); od = ImageDraw.Draw(ov)
        od.ellipse([-360, -260, W + 360, H + 260], fill=255)
        ov = ov.filter(ImageFilter.GaussianBlur(180))
        _VIG = ov.point(lambda v: 150 + v * 105 // 255)
    return Image.composite(img, Image.new("RGB", (W, H), (0, 0, 0)), _VIG)

BLACK = Image.new("RGB", (W, H), (0, 0, 0))
PARTS = [((i * 173) % W, (i * 389) % H, 2 + (i % 4), 14 + (i % 5) * 9) for i in range(40)]

def plate_frame(plate, z, cx=0.5, cy=0.5, dim=0.0, life_t=None):
    """Crop `plate` (supersampled) at zoom z around fractional centre, resize to output."""
    pw, ph = plate.size
    cw, ch = pw / z, ph / z
    x0 = min(max(cx * pw - cw / 2, 0), pw - cw); y0 = min(max(cy * ph - ch / 2, 0), ph - ch)
    img = plate.crop((int(x0), int(y0), int(x0 + cw), int(y0 + ch))).resize((W, H), Image.LANCZOS)
    img = vignette(img)
    if dim > 0: img = Image.blend(img, BLACK, dim)
    if life_t is not None:
        d = ImageDraw.Draw(img, "RGBA")
        for i, (x, y, r, sp) in enumerate(PARTS):
            yy = (y + life_t * sp) % H; xx = x + int(20 * math.sin(life_t * 0.7 + i))
            d.ellipse([xx - r, yy - r, xx + r, yy + r], fill=(255, 214, 130, 40))
    return img

class ZoomTrack:
    """Base eased zoom + cumulative eased punch-in steps."""
    def __init__(self, z0, z1, dur):
        self.z0, self.z1, self.dur = z0, z1, dur; self.punches = []
    def punch(self, t0, dz, dur=0.4):
        self.punches.append((t0, dz, dur)); return self
    def at(self, t):
        z = self.z0 + (self.z1 - self.z0) * ease_inout(t / self.dur)
        for t0, dz, d in self.punches:
            if t > t0: z += dz * ease_out(min((t - t0) / d, 1.0))
        return z

# ---------------- captions: character-weighted word pop ----------------
def phrase_spans(phrases, dur):
    """phrases = [(text, hot)] -> [(start, end)] weighted by character count."""
    weights = [max(len(t), 1) for t, _ in phrases]
    tot = sum(weights); out = []; acc = 0.0
    for wgt in weights:
        span = dur * wgt / tot; out.append((acc, acc + span)); acc += span
    return out

def draw_caption(img, phrases, spans, t):
    for (text, hot), (a, b) in zip(phrases, spans):
        if a <= t < b or (t >= b and (text, hot) == phrases[-1] and t < spans[-1][1] + 0.001):
            words = text.split()
            wts = [max(len(wd), 1) for wd in words]; tot = sum(wts)
            local = (t - a) / max(b - a, 0.01)
            acc = 0.0; show = []
            for wd, wgt in zip(words, wts):
                wstart = acc / tot; acc += wgt
                if local >= wstart: show.append((wd, (local - wstart) * (b - a)))
            if not show: return
            scratch = ImageDraw.Draw(Image.new("RGB", (10, 10)))
            def wsz(wd): return 66 if wd.strip("?!.,—-:;").casefold() == (hot or "").casefold() and hot else 58
            lines, cur = [], []
            for wd, age in show:
                trial = cur + [(wd, age)]
                width = sum(tw(scratch, w2, F(wsz(w2)), 5)[0] for w2, _ in trial) + 18 * (len(trial) - 1)
                if width <= 940 or not cur: cur = trial
                else: lines.append(cur); cur = [(wd, age)]
            if cur: lines.append(cur)
            ph = len(lines) * 78 + 44
            d = ImageDraw.Draw(img, "RGBA")
            d.rounded_rectangle([54, H - 130 - ph, W - 54, H - 108], radius=26, fill=(0, 0, 0, 185))
            yy = H - 130 - ph + 22
            for ln in lines:
                widths = [tw(d, wd, F(wsz(wd)), 5)[0] for wd, _ in ln]
                total = sum(widths) + 18 * (len(ln) - 1); xx = (W - total) // 2
                for (wd, age), wdx in zip(ln, widths):
                    size = wsz(wd)
                    if age < 0.14: size = int(size * (1.16 - 0.16 * (age / 0.14)))  # pop decay
                    ff = F(size)
                    colr = GOLD + (255,) if wsz(wd) == 66 else WHITE + (255,)
                    bb = d.textbbox((0, 0), wd, font=ff, stroke_width=5)
                    d.text((xx - bb[0], yy - (10 if age < 0.14 else 0)), wd, font=ff,
                           fill=colr, stroke_width=5, stroke_fill=(0, 0, 0, 235))
                    xx += wdx + 18
                yy += 78
            return

def count_up(target, elapsed, dur=0.55):
    return int(target * ease_out(min(max(elapsed, 0) / dur, 1.0)))

def big_number(img, value, cy=800, size=300):
    d = ImageDraw.Draw(img, "RGBA"); cx = W // 2
    for k in range(3, 0, -1):
        rr = 250 * (1 + 0.3 * k)
        d.ellipse([cx - rr, cy - rr * 0.62, cx + rr, cy + rr * 0.62], fill=(255, 190, 60, 14 // k + 8))
    txt = str(value); f = F(size); w, bb = tw(d, txt, f, 12)
    d.text((cx - w / 2 - bb[0], cy - size // 2), txt, font=f, fill=GOLD,
           stroke_width=12, stroke_fill=(0, 0, 0, 240))

def type_on(d, cx, y, text, t, t0, cps=14, size=44, fill=GOLD, sw=6):
    """Typewriter label, STEPPED at 12 fps (craft B5: graphics may step, plates may not)."""
    step_t = math.floor(t * 12) / 12
    n = int(min(max((step_t - t0) * cps, 0), len(text)))
    if n <= 0: return 0
    return ctext(d, cx, y, text[:n], F(size), fill, sw)

# ---------------- audio synth (ported from production builder, SR=44100) ----------------
def smooth(x, win):
    if win <= 1: return x
    return np.convolve(x, np.ones(win, dtype=np.float32) / win, mode="same")

def music_bed(freqs, total, gain_scale=0.30):
    n = int(total * SR); t = np.arange(n, dtype=np.float32) / SR
    sig = np.zeros(n, dtype=np.float32)
    for i, fq in enumerate(freqs):
        wgt = 0.5 if i == 0 else 0.30
        sig += wgt * np.sin(2 * np.pi * fq * t + 0.35 * np.sin(2 * np.pi * 0.05 * t + i))
        sig += 0.12 * np.sin(2 * np.pi * fq * 2.0 * t)
    sig *= 0.82 + 0.18 * np.sin(2 * np.pi * 0.08 * t)
    env = np.clip(t / 1.6, 0, 1) * np.clip((total - t) / 2.0, 0, 1)
    return (sig * env) * gain_scale

def sfx_whoosh(rng, dur_s=0.42):
    n = int(dur_s * SR); x = smooth(rng.standard_normal(n).astype(np.float32), 200) * 6
    return x * (np.sin(np.pi * np.arange(n) / n) ** 1.5) * 0.5

def sfx_hit(dur_s=0.5):
    n = int(dur_s * SR); t = np.arange(n) / SR
    return (np.sin(2 * np.pi * 54 * t) * np.exp(-t * 11) + 0.5 * np.sin(2 * np.pi * 108 * t) * np.exp(-t * 16)) * 0.9

def sfx_riser(rng, dur_s=1.2):
    n = int(dur_s * SR); t = np.arange(n) / SR
    fq = 170 * (1350 / 170) ** (t / dur_s); ph = np.cumsum(2 * np.pi * fq / SR)
    x = np.sin(ph) * 0.5 + 0.25 * rng.standard_normal(n).astype(np.float32)
    return x * ((t / dur_s) ** 1.6) * 0.55

def sfx_click():
    n = int(0.03 * SR); t = np.arange(n) / SR
    return np.sin(2 * np.pi * 2200 * t) * np.exp(-t * 160) * 0.25

def place(track, clip, t0, gain=1.0):
    i0 = int(t0 * SR); i1 = min(len(track), i0 + len(clip))
    if i0 >= len(track): return
    track[i0:i1] += clip[:i1 - i0] * gain

def decode_audio(path, sr=SR):
    raw = run(f"ffmpeg -v error -i {path} -ac 1 -ar {sr} -f f32le -").stdout \
        if False else subprocess.run(
            f"ffmpeg -v error -i {path} -ac 1 -ar {sr} -f f32le -",
            shell=True, capture_output=True).stdout
    return np.frombuffer(raw, dtype=np.float32).copy()

def write_wav_stereo(path, mono, sr=SR):
    import wave
    st = np.clip(np.stack([mono, mono], axis=1), -1, 1)
    with wave.open(path, "wb") as wf:
        wf.setnchannels(2); wf.setsampwidth(2); wf.setframerate(sr)
        wf.writeframes((st * 32767).astype(np.int16).tobytes())

def vo_line(n):
    return decode_audio(os.path.join(VO_DIR, f"l{n}.mp3"))

def pipe_frames(out_path, frame_iter, total_s, audio_path=None):
    cmd = (f"ffmpeg -y -loglevel error -f rawvideo -pix_fmt rgb24 -s {W}x{H} -r {FPS} -i - "
           + (f"-i {audio_path} -map 0:v -map 1:a -c:a aac -b:a 160k " if audio_path else "-an ")
           + f"-c:v libx264 -crf 20 -preset veryfast -pix_fmt yuv420p -movflags +faststart {out_path}")
    pr = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE)
    for fr in frame_iter:
        pr.stdin.write(fr.tobytes())
    pr.stdin.close(); pr.wait()
    if pr.returncode != 0: print("ENCODE FAILED", out_path); sys.exit(1)
