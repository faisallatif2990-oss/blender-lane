# -*- coding: utf-8 -*-
"""Shared machinery for the P17+ Rathee-skill prototypes (2026-11-15 evening).
Landscape 1920x1080 @ 24fps, locked Hindi VO (tts --language hi, speed 95,
natural speed only), English on-screen text, single small caption layer with
gold hot-words, masters loudnormed to -14 LUFS / TP <= -1.0 dBTP.
Reuses lab_common for fonts, grade v2, easing, SFX and audio primitives.
"""
import json, math, os, subprocess, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lab_common as lc
from lab_common import (count_up, big_number, F, tw, ctext, ease_inout, ease_out, ease_out_quint,
                        grade_v2, music_bed, place, write_wav_stereo,
                        decode_audio, sfx_whoosh, sfx_hit, sfx_riser, sfx_click,
                        GOLD, GOLD2, WHITE, AMBER, TEAL, SR)

LAB = os.path.dirname(os.path.abspath(__file__))
W, H, FPS = 1920, 1080, 24
GEO = os.path.expanduser("~/workspace/history-vault/assets/geo-library")
V4 = os.path.expanduser("~/workspace/history-vault/production/2026-11-15-long1-v4/plates")
KNOWP = os.path.expanduser("~/workspace/history-vault/production/2026-11-15-knowledge/plates")
RED = (232, 49, 44)
DARK = (10, 12, 16)

def run(cmd, **kw):
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True, **kw)
    if r.returncode != 0:
        print("FAILED:", cmd[:220]); print(r.stderr[-1200:]); sys.exit(1)
    return r

# ---------------- plates (landscape) ----------------
_VIGL = None
def vignette_l(img):
    global _VIGL
    if _VIGL is None:
        ov = Image.new("L", (W, H), 0); od = ImageDraw.Draw(ov)
        od.ellipse([-int(W * 0.28), -int(H * 0.30), int(W * 1.28), int(H * 1.30)], fill=255)
        ov = ov.filter(ImageFilter.GaussianBlur(120))
        _VIGL = ov.point(lambda v: 165 + v * 90 // 255)
    return Image.composite(img, Image.new("RGB", (W, H), (0, 0, 0)), _VIGL)

_plate_cache = {}
def load_plate(path, ss=2, grade=True):
    key = (path, ss, grade)
    if key in _plate_cache: return _plate_cache[key]
    im = Image.open(path).convert("RGB")
    if grade: im = grade_v2(im)
    if ss != 1: im = im.resize((im.width * ss, im.height * ss), Image.LANCZOS)
    _plate_cache[key] = im
    return im

def frame_from(plate, z=1.0, cx=0.5, cy=0.5, dim=0.0):
    pw, ph = plate.size
    cw, ch = pw / z, ph / z
    # keep the crop's aspect matched to 16:9 as closely as the plate allows
    x0 = min(max(cx * pw - cw / 2, 0), pw - cw); y0 = min(max(cy * ph - ch / 2, 0), ph - ch)
    img = plate.crop((int(x0), int(y0), int(x0 + cw), int(y0 + ch))).resize((W, H), Image.LANCZOS)
    img = vignette_l(img)
    if dim > 0: img = Image.blend(img, Image.new("RGB", (W, H), (0, 0, 0)), dim)
    return img

def solid(col=(16, 18, 24)):
    return Image.new("RGB", (W, H), col)

# ---------------- text helpers ----------------
def chip(d, cx, y, text, size=44, fg=GOLD, bg=(0, 0, 0, 200), pad_x=26, sw=5):
    f = F(size); w, bb = tw(d, text, f, sw)
    wtot = w + pad_x * 2; hgt = int(size * 1.28) + 18
    d.rounded_rectangle([cx - wtot / 2, y, cx + wtot / 2, y + hgt], radius=14, fill=bg)
    d.text((cx - w / 2 - bb[0], y + 9 - bb[1]), text, font=f, fill=fg, stroke_width=sw,
           stroke_fill=(0, 0, 0, 235))
    return hgt

def date_chip(d, text, x=56, y=None, size=36):
    # top-left by default: the bottom-left default (H-190) is swallowed by
    # the caption pill whenever a caption runs to two lines (seen on P21)
    if y is None: y = 96
    f = F(size); w, bb = tw(d, text, f, 4)
    d.rounded_rectangle([x - 14, y - 8, x + w + 14, y + int(size * 1.28) + 8], radius=8,
                        fill=(0, 0, 0, 190))
    d.text((x - bb[0], y - bb[1]), text, font=f, fill=WHITE, stroke_width=4,
           stroke_fill=(0, 0, 0, 235))

def disc(img, cx, cy, r, photo=None, initials=None, ring=GOLD, label=None, label_size=40):
    """Circular photo disc (or initial disc) with ring + optional name under."""
    if photo is not None:
        ph = photo.resize((r * 2, r * 2), Image.LANCZOS)
        mask = Image.new("L", (r * 2, r * 2), 0)
        ImageDraw.Draw(mask).ellipse([0, 0, r * 2, r * 2], fill=255)
        img.paste(ph, (cx - r, cy - r), mask)
    else:
        d0 = ImageDraw.Draw(img)
        d0.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(38, 44, 56))
        if initials:
            ctext(d0, cx, cy - int(label_size * 0.62), initials, F(int(r * 0.72)), GOLD, 4)
    d = ImageDraw.Draw(img, "RGBA")
    d.ellipse([cx - r - 4, cy - r - 4, cx + r + 4, cy + r + 4], outline=ring + (255,), width=6)
    if label:
        ctext(d, cx, cy + r + 16, label, F(label_size), WHITE, 6)

def face_crop(path, box, size=480):
    """Square face-ish crop from a plate, as an image (for discs)."""
    im = Image.open(path).convert("RGB")
    x0, y0, x1, y1 = box
    return im.crop((x0, y0, x1, y1)).resize((size, size), Image.LANCZOS)

# ---------------- captions: single small layer, word-pop, gold hot-words -------
class Caps:
    def __init__(self):
        self.items = []  # (start, end, text, hot)
    def add(self, start, end, text, hot=None):
        self.items.append((start, end, text, hot)); return self
    def draw(self, img, t):
        for a, b, text, hot in self.items:
            if not (a <= t < b): continue
            words = text.split()
            wts = [max(len(w), 1) for w in words]; tot = sum(wts)
            local = (t - a) / max(b - a, 0.01); acc = 0.0; show = []
            for wd, wgt in zip(words, wts):
                ws = acc / tot; acc += wgt
                if local >= ws: show.append((wd, (local - ws) * (b - a)))
            if not show: return
            def wsz(wd): return 60 if hot and wd.strip("?!.,—-:;").casefold() == hot.casefold() else 50
            scratch = ImageDraw.Draw(Image.new("RGB", (10, 10)))
            lines, cur = [], []
            for wd, age in show:
                trial = cur + [(wd, age)]
                width = sum(tw(scratch, w2, F(wsz(w2)), 5)[0] for w2, _ in trial) + 16 * (len(trial) - 1)
                if width <= 1560 or not cur: cur = trial
                else: lines.append(cur); cur = [(wd, age)]
            if cur: lines.append(cur)
            ph = len(lines) * 68 + 36
            d = ImageDraw.Draw(img, "RGBA")
            # clean-caption rule (owner, 2026-11-15 ~21:42): the pill hugs
            # the text — width adapts to the longest visible line instead
            # of a fixed heavy bar across the frame
            line_totals = []
            for ln in lines:
                ws_ = [tw(d, wd, F(wsz(wd)), 5)[0] for wd, _ in ln]
                line_totals.append(sum(ws_) + 16 * (len(ln) - 1))
            half = min(830, max(line_totals) // 2 + 46) if line_totals else 300
            d.rounded_rectangle([W // 2 - half, H - 64 - ph, W // 2 + half, H - 46], radius=22,
                                fill=(0, 0, 0, 168))
            yy = H - 64 - ph + 18
            for ln in lines:
                widths = [tw(d, wd, F(wsz(wd)), 5)[0] for wd, _ in ln]
                total = sum(widths) + 16 * (len(ln) - 1); xx = (W - total) // 2
                for (wd, age), wdx in zip(ln, widths):
                    size = wsz(wd)
                    if age < 0.14: size = int(size * (1.15 - 0.15 * (age / 0.14)))
                    ff = F(size)
                    colr = GOLD + (255,) if wsz(wd) == 60 else WHITE + (255,)
                    bb = d.textbbox((0, 0), wd, font=ff, stroke_width=5)
                    d.text((xx - bb[0], yy - (9 if age < 0.14 else 0)), wd, font=ff, fill=colr,
                           stroke_width=5, stroke_fill=(0, 0, 0, 235))
                    xx += wdx + 16
                yy += 68
            return

# ---------------- VO: locked Hindi TTS, natural speed -------------------------
def synth_vo(lines, tag, speed=95):
    """lines: list of Hindi strings. Returns dict(starts, durs, arrays, total)."""
    meta_path = os.path.join(LAB, f"{tag}_vo.json")
    arrays, durs = [], []
    for i, ln in enumerate(lines):
        mp3 = os.path.join(LAB, f"{tag}_vo_{i}.mp3")
        if not (os.path.exists(mp3) and os.path.getsize(mp3) > 1000):
            run(f"/opt/hatch/bin/tts --text {json.dumps(ln, ensure_ascii=False)} "
                f"--language hi --speed {speed} --output {mp3}")
        arr = decode_audio(mp3)
        arrays.append(arr); durs.append(len(arr) / SR)
    json.dump({"lines": lines, "durs": durs}, open(meta_path, "w"), ensure_ascii=False)
    return {"arrays": arrays, "durs": durs}

def layout(durs, gap=0.35, start=0.15):
    starts, t = [], start
    for d in durs:
        starts.append(t); t += d + gap
    return starts, t - gap  # starts, vo_end

# ---------------- audio assembly --------------------------------------------
def build_track(total, vo, starts, music_freqs=(55.0, 82.4, 110.0), music_gain=0.30,
                sfx=(), silences=(), seed=7, vo_gain=1.0):
    """sfx: (kind, t0, gain) kind in whoosh/hit/riser/click. silences: (a,b)."""
    rng = np.random.default_rng(seed)
    n = int(total * SR)
    track = np.zeros(n, dtype=np.float32)
    bed = music_bed(list(music_freqs), total, gain_scale=music_gain)
    track[:len(bed)] += bed[:n]
    for arr, s in zip(vo, starts):
        place(track, arr * vo_gain, s)
    cache = {}
    for kind, t0, g in sfx:
        if kind not in cache:
            cache[kind] = {"whoosh": sfx_whoosh(rng), "hit": sfx_hit(),
                           "riser": sfx_riser(rng), "click": sfx_click()}[kind]
        place(track, cache[kind], t0, g)
    for a, b in silences:  # scripted mute with 60 ms fades
        i0, i1 = int(a * SR), int(b * SR); fade = int(0.06 * SR)
        seg = track[i0:i1]
        env = np.ones(len(seg), dtype=np.float32)
        if len(seg) > 2 * fade:
            env[:fade] = np.linspace(1, 0, fade); env[-fade:] = np.linspace(0, 1, fade)
        track[i0:i1] = seg * env * 0.02
    # premix discipline (mix-chain spec): cap premix peak at -4 dBFS so the
    # two-pass loudnorm stays linear and cannot overshoot the TP ceiling
    peak = float(np.max(np.abs(track))) if len(track) else 0.0
    if peak > 0.63:
        track = track * (0.63 / peak)
    wav = os.path.join(LAB, "_tmp_track.wav")
    write_wav_stereo(wav, track)
    return wav

# ---------------- encode + loudnorm + QC ------------------------------------
def _loudnorm_measure(path):
    """Full-output regex extraction — never tail-slice ffmpeg output: on
    longer files the JSON's opening brace falls above any fixed tail cut
    (this bug killed the first two P17 runs after successful renders)."""
    import re
    r = subprocess.run(f"ffmpeg -i {path} -vn -af loudnorm=I=-14:TP=-1.0:LRA=11:"
                       f"print_format=json -f null -",
                       shell=True, capture_output=True, text=True)
    txt = r.stderr + r.stdout
    blocks = re.findall(r"\{[^{}]*\"input_i\"[^{}]*\}", txt)
    if not blocks:
        print("LOUDNORM MEASURE FAILED for", path); print(txt[-1500:]); sys.exit(1)
    return json.loads(blocks[-1])

def encode(frames_iter, total, audio_wav, tag):
    raw = os.path.join(LAB, f"{tag}_raw.mp4")
    cmd = (f"ffmpeg -y -loglevel error -f rawvideo -pix_fmt rgb24 -s {W}x{H} -r {FPS} -i - "
           f"-i {audio_wav} -map 0:v -map 1:a -c:a aac -b:a 160k "
           f"-c:v libx264 -crf 18 -preset veryfast -pix_fmt yuv420p {raw}")
    pr = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE)
    for fr in frames_iter:
        pr.stdin.write(fr.tobytes())
    pr.stdin.close(); pr.wait()
    if pr.returncode != 0: print("ENCODE FAILED", tag); sys.exit(1)
    m = _loudnorm_measure(raw)
    master = os.path.join(LAB, f"{tag}.mp4")
    af = (f"loudnorm=I=-14:TP=-1.0:LRA=11:measured_I={m['input_i']}:measured_TP={m['input_tp']}"
          f":measured_LRA={m['input_lra']}:measured_thresh={m['input_thresh']}"
          f":offset={m['target_offset']}:linear=true,alimiter=limit=0.84:level=false")
    run(f"ffmpeg -y -loglevel error -i {raw} -af {af} -c:v copy -c:a aac -b:a 160k "
        f"-movflags +faststart {master}")
    review = os.path.join(LAB, f"{tag}_review.mp4")
    run(f"ffmpeg -y -loglevel error -i {master} -c:v libx264 -profile:v main -crf 26 "
        f"-preset veryfast -pix_fmt yuv420p -c:a aac -b:a 128k -movflags +faststart {review}")
    os.remove(raw)
    return master, review

def finalize_raw(raw, tag):
    """Loudnorm-apply + review + QC from an existing rendered raw file
    (salvage path when a build died after the render step)."""
    m = _loudnorm_measure(raw)
    master = os.path.join(LAB, f"{tag}.mp4")
    af = (f"loudnorm=I=-14:TP=-1.0:LRA=11:measured_I={m['input_i']}:measured_TP={m['input_tp']}"
          f":measured_LRA={m['input_lra']}:measured_thresh={m['input_thresh']}"
          f":offset={m['target_offset']}:linear=true,alimiter=limit=0.84:level=false")
    run(f"ffmpeg -y -loglevel error -i {raw} -af {af} -c:v copy -c:a aac -b:a 160k "
        f"-movflags +faststart {master}")
    review = os.path.join(LAB, f"{tag}_review.mp4")
    run(f"ffmpeg -y -loglevel error -i {master} -c:v libx264 -profile:v main -crf 26 "
        f"-preset veryfast -pix_fmt yuv420p -c:a aac -b:a 128k -movflags +faststart {review}")
    os.remove(raw)
    q = qc(master, tag)
    print(f"QC {tag}: decode_ok={q['decode_ok']} LUFS={q['lufs']:.2f} TP={q['tp']:.2f} "
          f"dur={q['dur']:.2f}s grabs={q['grabs']}")
    return q

def qc(path, tag):
    dec = subprocess.run(f"ffmpeg -v error -xerror -i {path} -f null -",
                         shell=True, capture_output=True, text=True)
    decode_ok = dec.returncode == 0 and not dec.stderr.strip()
    m = _loudnorm_measure(path)
    dur = float(run(f"ffprobe -v error -show_entries format=duration -of csv=p=0 {path}").stdout)
    chk = os.path.join(LAB, "checks", tag); os.makedirs(chk, exist_ok=True)
    grabs = []
    for name, frac in (("a", 0.08), ("b", 0.5), ("c", 0.92)):
        g = os.path.join(chk, f"{name}.jpg")
        run(f"ffmpeg -y -loglevel error -ss {dur * frac:.2f} -i {path} -frames:v 1 -q:v 3 {g}")
        grabs.append(g)
    return {"decode_ok": decode_ok, "lufs": float(m["input_i"]), "tp": float(m["input_tp"]),
            "dur": dur, "grabs": grabs}

def frames_gen(total, draw_fn):
    n = int(total * FPS)
    for i in range(n):
        yield draw_fn(i / FPS)

def finish(tag, total, draw_fn, audio_wav):
    master, review = encode(frames_gen(total, draw_fn), total, audio_wav, tag)
    q = qc(master, tag)
    print(f"QC {tag}: decode_ok={q['decode_ok']} LUFS={q['lufs']:.2f} TP={q['tp']:.2f} "
          f"dur={q['dur']:.2f}s grabs={q['grabs']}")
    return q
