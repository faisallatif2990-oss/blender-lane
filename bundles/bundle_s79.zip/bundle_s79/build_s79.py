# -*- coding: utf-8 -*-
"""Skill #79 — The false ending.
Route: 3dviz-pro-max — stylised 3D scene (two-act square), CPU. Fresh
original showcase: a town celebrates its finished bridge in a stylised
square; a "THE END" banner unfurls — then the banner is stamped "THE
FILM VERSION" and tears in two; the same square returns at night,
emptied, as a scaffold silhouette rises in the middle of it. Stylised
scene drawn with the house PIL pipeline (extruded-block buildings,
parallax crowd, day->night grade shift). English on-screen text, locked
Hindi VO (tts speed 95, natural speed, pre-generated in this bundle),
clean small captions with gold hot-words, -14 LUFS master.
Lane needs: python3 + Pillow + numpy, ffmpeg. No network, no tts.
"""
import os, sys, math, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "house"))
from PIL import Image, ImageDraw, ImageFilter, ImageChops
import numpy as np
import proto_common as pc
from proto_common import (W, H, F, tw, ctext, ease_out, ease_inout, GOLD,
                          WHITE, Caps, synth_vo, layout, build_track,
                          finish, vignette_l)
from lab_common import FB, FS, FSB, FM, FMB

pc.LAB = HERE
TAG = "s79"
RED = (205, 52, 40)

LINES = [
    # EN: The bridge was built, the town rejoiced — and the story ended.
    "पुल बन गया, शहर झूम उठा — और कहानी ख़त्म।",
    # EN: But this is the film ending — the real story starts here.
    "पर यह फ़िल्म वाला अंत है — असली कहानी यहाँ से शुरू होती है।",
    # EN: In the same square, the same month — the gallows was raised.
    "उसी चौक में, उसी महीने — फाँसी का तख़्ता खड़ा हुआ।",
]
CAPS = [
    ("The bridge is built — the town celebrates — THE END", "END"),
    ("That was the FILM version — the real story starts now", "FILM"),
    ("The same square, the same month — the GALLOWS rose", "GALLOWS"),
]

def lerp(a, b, p):
    return tuple(int(a[i] + (b[i] - a[i]) * p) for i in range(3))

DAY = {"sky_t": (128, 178, 228), "sky_b": (216, 236, 250), "ground": (198, 180, 142),
       "ground_f": (172, 154, 116), "face": (216, 166, 112), "side": (186, 136, 90),
       "top": (232, 196, 140), "bridge": (120, 110, 104), "ink": (40, 36, 30)}
NIGHT = {"sky_t": (12, 18, 40), "sky_b": (34, 42, 70), "ground": (50, 52, 66),
         "ground_f": (38, 40, 52), "face": (56, 58, 74), "side": (42, 44, 58),
         "top": (66, 68, 84), "bridge": (30, 32, 44), "ink": (200, 204, 220)}

_rng = np.random.default_rng(79)
CROWD = [(int(_rng.integers(180, W - 180)), int(_rng.integers(830, 990)),
          float(_rng.uniform(0, 6.28)), int(_rng.integers(15, 21))) for _ in range(42)]
CONF = [(int(_rng.integers(0, W)), int(_rng.integers(0, H)), float(_rng.uniform(14, 30)),
         float(_rng.uniform(0, 6.28))) for _ in range(60)]
BLDGS = [  # x, base_y, w, h, depth
    (60, 800, 300, 430, 44), (390, 800, 240, 330, 38), (1290, 800, 250, 360, 40),
    (1570, 800, 290, 460, 46), (700, 790, 170, 210, 30), (1050, 790, 170, 190, 30),
]

def box(d, x, yb, w, h, dep, pal, night):
    face = lerp(pal["face"], NIGHT["face"], night) if False else pal["face"]
    d.polygon([(x, yb - h), (x + dep, yb - h - dep // 2), (x + w + dep, yb - h - dep // 2),
               (x + w, yb - h)], fill=pal["top"] + (255,))
    d.polygon([(x + w, yb - h), (x + w + dep, yb - h - dep // 2), (x + w + dep, yb - dep // 2),
               (x + w, yb)], fill=pal["side"] + (255,))
    d.rectangle([x, yb - h, x + w, yb], fill=face + (255,))
    # windows
    cols, rows = max(w // 62, 1), max(h // 84, 1)
    for r in range(rows):
        for c in range(cols):
            wx, wy = x + 20 + c * 62, yb - h + 24 + r * 84
            lit = ((r * 7 + c * 3 + x) % 5 == 0)
            col = (255, 214, 120, 235) if (lit and night > 0.4) else \
                  ((255, 240, 200, 160) if lit else (70, 74, 92, 200))
            d.rectangle([wx, wy, wx + 30, wy + 42], fill=col)

def stamp_img():
    w, h = 760, 180
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([8, 8, w - 8, h - 8], radius=10, outline=RED + (255,), width=9)
    d.rounded_rectangle([24, 24, w - 24, h - 24], radius=6, outline=RED + (255,), width=3)
    ctext(d, w // 2, h // 2 - 40, "THE FILM VERSION", F(76), RED + (255,), 1)
    return img.rotate(-9, resample=Image.BICUBIC, expand=True)

STAMP = stamp_img()

def _compute(durs):
    starts, vo_end = layout(durs, gap=0.30)
    return starts, vo_end

try:
    _durs0 = json.load(open(os.path.join(HERE, f"{TAG}_vo.json")))["durs"]
except Exception:
    _durs0 = [2.8, 3.4, 3.0]
STARTS, VO_END = _compute(_durs0)

def banner_layer(p, tear, night):
    """The THE END banner: unfurls with p, tears into two halves with tear."""
    w, h = 1300, 150
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    cloth = lerp((244, 238, 220), (120, 122, 134), night)
    edge = lerp((198, 44, 32), (110, 40, 34), night)
    uw = int(w * p)
    if uw > 8:
        pts_t = [(x, 8 + 6 * math.sin(x / 90.0)) for x in range(0, uw, 26)]
        pts_b = [(x, h - 14 + 10 * math.sin(x / 90.0 + 1.2)) for x in range(uw, -1, -26)]
        d.polygon(pts_t + pts_b, fill=cloth + (255,), outline=edge + (255,))
        if p > 0.72:
            ctext(d, uw // 2, 44, "THE END", F(74), lerp((150, 32, 24), (90, 30, 26), night), 1)
    if tear <= 0:
        return img, 0, 0
    # split into halves that rotate apart and drop
    half = w // 2
    left = img.crop((0, 0, half, h)).rotate(5 + 7 * tear, resample=Image.BICUBIC, expand=True)
    right = img.crop((half, 0, w, h)).rotate(-5 - 7 * tear, resample=Image.BICUBIC, expand=True)
    out = Image.new("RGBA", (w + 160, h + 260), (0, 0, 0, 0))
    out.paste(left, (int(-30 - 60 * tear), int(10 + 130 * tear)), left)
    out.paste(right, (int(half - 40 + 60 * tear), int(10 + 130 * tear)), right)
    return out, -80, -10

def draw(t):
    s1, s2, s3 = STARTS
    tear_t = s3 - 0.05
    night = ease_inout(min(max((t - tear_t) / 1.4, 0.0), 1.0)) if t > tear_t else 0.0
    pal = {k: lerp(DAY[k], NIGHT[k], night) for k in DAY}
    img = Image.new("RGB", (W, H), pal["sky_b"])
    d = ImageDraw.Draw(img, "RGBA")
    # sky gradient
    for yy in range(0, 700, 8):
        d.rectangle([0, yy, W, yy + 8], fill=lerp(pal["sky_t"], pal["sky_b"], yy / 700) + (255,))
    if night > 0.3:
        d.ellipse([1560, 90, 1650, 180], fill=(232, 236, 246, int(220 * night)))
        d.ellipse([1530, 76, 1618, 164], fill=pal["sky_t"] + (int(160 * night),))
    # distant bridge (the celebrated bridge) — arch + two towers
    bx0, bx1, by = 660, 1260, 700
    d.rectangle([bx0, by - 190, bx0 + 46, by], fill=pal["bridge"] + (255,))
    d.rectangle([bx1 - 46, by - 190, bx1, by], fill=pal["bridge"] + (255,))
    d.rectangle([bx0, by - 205, bx1, by - 178], fill=pal["bridge"] + (255,))
    d.arc([bx0 + 60, by - 190, bx1 - 60, by + 130], start=180, end=360,
          fill=pal["bridge"] + (255,), width=16)
    # ground
    d.polygon([(0, 700), (W, 700), (W, H), (0, H)], fill=pal["ground"] + (255,))
    d.polygon([(0, 880), (W, 880), (W, H), (0, H)], fill=pal["ground_f"] + (255,))
    # buildings
    for x, yb, w, h, dep in BLDGS:
        box(d, x, yb, w, h, dep, pal, night)
    # banner poles
    for px in (300, 1620):
        d.rectangle([px - 7, 150, px + 7, 800], fill=lerp((96, 74, 52), (30, 30, 40), night) + (255,))
        d.ellipse([px - 13, 138, px + 13, 164], fill=GOLD + (255,) if night < 0.5 else (120, 124, 140, 255))
    # banner (unfurls during line 1, tears at the act break)
    bp = ease_out(min(max((t - (s1 + 0.7)) / 1.1, 0.0), 1.0))
    tear = ease_inout(min(max((t - tear_t) / 0.7, 0.0), 1.0)) if t > tear_t else 0.0
    if bp > 0:
        bl, ox, oy = banner_layer(bp, tear, night)
        img.paste(bl, (307 + ox, 168 + oy), bl)
        d = ImageDraw.Draw(img, "RGBA")
    # stamp slams on the banner during line 2
    stamp_t = s2 + 0.55
    if stamp_t <= t and tear < 0.9:
        st = t - stamp_t
        sc = 1.3 - 0.3 * ease_out(min(st / 0.18, 1.0))
        simg = STAMP.resize((int(STAMP.width * sc), int(STAMP.height * sc)), Image.LANCZOS)
        fade = 1.0 if tear <= 0 else max(1.0 - tear * 1.6, 0.0)
        if fade > 0:
            if fade < 1.0:
                a = simg.split()[3].point(lambda v: int(v * fade))
                simg.putalpha(a)
            img.paste(simg, (W // 2 - simg.width // 2, 150), simg)
            d = ImageDraw.Draw(img, "RGBA")
    # crowd celebrates (act 1 only; the square empties as it darkens)
    if night < 0.85:
        alpha = int(255 * (1 - night))
        for x, y, ph, r in CROWD:
            bob = int(5 * math.sin(t * 3.1 + ph)) if night < 0.2 else 0
            col = lerp((52, 48, 60), (16, 16, 22), night)
            d.ellipse([x - r // 2, y - 2 * r + bob, x + r // 2, y - r + bob], fill=col + (alpha,))
            d.rectangle([x - r // 2 - 2, y - r + bob, x + r // 2 + 2, y + 6 + bob], fill=col + (alpha,))
        if night < 0.2:
            for x, y, sp, ph in CONF:
                yy = (y + t * sp * 6) % (H + 40) - 20
                d.rectangle([x, yy, x + 9, yy + 5], fill=(240, 120, 110, 200))
    # scaffold rises at centre during line 3
    if t > s3 + 0.25:
        rp = ease_inout(min((t - s3 - 0.25) / 1.6, 1.0))
        gy = 892
        top = gy - int(330 * rp)
        col = (10, 10, 14, 255)
        d.rectangle([838, top, 856, gy], fill=col)
        d.rectangle([1064, top, 1082, gy], fill=col)
        if rp > 0.55:
            bp2 = (rp - 0.55) / 0.45
            d.rectangle([818, top, 1102, top + 20], fill=col)
            d.line([856, top + 130, 1064, top + 20], fill=col, width=10)
            if bp2 > 0.5:
                rx = 1006
                d.line([rx, top + 20, rx, top + 104], fill=col, width=6)
                d.ellipse([rx - 17, top + 100, rx + 17, top + 148], outline=col, width=6)
        d.ellipse([700, gy - 6, 1220, gy + 10], fill=(0, 0, 0, 90))
    return vignette_l(img)

def tighten(tag):
    """House TP discipline: if the master measures above -1.5 dBTP, trim the
    audio by the excess and re-limit (the s52 'TP-tightening pass')."""
    master = os.path.join(HERE, f"{tag}.mp4")
    q = pc.qc(master, tag)
    if q["tp"] > -1.5:
        gain = -1.55 - q["tp"]
        tmp = os.path.join(HERE, f"{tag}_tp.mp4")
        pc.run(f"ffmpeg -y -loglevel error -i {master} -af volume={gain:.2f}dB,"
               f"alimiter=limit=0.80:level=false -c:v copy -c:a aac -b:a 160k "
               f"-movflags +faststart {tmp}")
        os.replace(tmp, master)
        review = os.path.join(HERE, f"{tag}_review.mp4")
        pc.run(f"ffmpeg -y -loglevel error -i {master} -c:v libx264 -profile:v main -crf 26 "
               f"-preset veryfast -pix_fmt yuv420p -c:a aac -b:a 128k -movflags +faststart {review}")
        q = pc.qc(master, tag)
        print(f"{tag} TP-tightened by {gain:.2f} dB -> LUFS={q['lufs']:.2f} TP={q['tp']:.2f}")
    return q

def main():
    global STARTS, VO_END
    vo = synth_vo(LINES, TAG)
    STARTS, VO_END = _compute(vo["durs"])
    starts = STARTS
    total = VO_END + 0.95
    caps = Caps()
    for s, dur, (txt, hot) in zip(starts, vo["durs"], CAPS):
        caps.add(s, s + dur + 0.25, txt, hot)
    sfx = [("whoosh", starts[0] + 0.7, 0.55), ("hit", starts[1] + 0.55, 1.0),
           ("riser", starts[2] - 0.05, 0.5), ("hit", starts[2] + 1.85, 0.8)]
    audio = build_track(total, vo["arrays"], starts, seed=53,
                        music_freqs=(55.0, 82.4, 110.0), sfx=sfx)

    def full(t):
        img = draw(t)
        caps.draw(img, t)
        return img

    finish(TAG, total, full, audio)
    q = tighten(TAG)
    print(TAG, "starts", [round(s, 2) for s in starts], "total", round(total, 2), "QC", q)

if __name__ == "__main__":
    main()
