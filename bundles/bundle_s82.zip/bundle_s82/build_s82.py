# -*- coding: utf-8 -*-
"""Skill #82 — The controlled re-run.
Route: 3dviz-pro-max — stylised 3D scene (canal experiment), CPU. Fresh
original showcase of the plan's named case (Bedford Level, 1838 ->
1870): a stylised canal stretches to the horizon; three marker poles
stand along it; the sight-line through their tops SAGS at the middle
pole; a side tag names the flaw — REFRACTION; the mid-pole rises (the
control the first test lacked), the line snaps straight through all
three markers: "THE EARTH CURVES". Stylised scene drawn with the house
PIL pipeline (perspective canal, fluttering flags, moving water).
English on-screen text, locked Hindi VO (tts speed 95, natural speed,
pre-generated in this bundle), clean small captions with gold
hot-words, -14 LUFS master.
Lane needs: python3 + Pillow + numpy, ffmpeg. No network, no tts.
"""
import os, sys, math, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "house"))
from PIL import Image, ImageDraw, ImageFilter, ImageChops
import numpy as np
import proto_common as pc
from proto_common import (W, H, F, tw, ctext, ease_out, ease_inout, GOLD,
                          WHITE, Caps, synth_vo, layout, build_track,
                          finish, vignette_l)
from lab_common import FB, FS, FSB, FM, FMB

pc.LAB = HERE
TAG = "s82"
RED = (205, 52, 40)
SKY_T, SKY_B = (150, 190, 224), (224, 238, 248)
WATER = (86, 128, 148)
WATER_D = (64, 104, 126)
BANK = (104, 128, 88)
BANK_D = (84, 106, 70)

LINES = [
    # EN: 1838 — three flags on the canal, and a claim of a straight line.
    "1838 — नहर पर तीन झंडे, और एक सीधी रेखा का दावा।",
    # EN: 1870 — the same experiment, but this time the middle pole was kept higher.
    "1870 — वही प्रयोग, पर इस बार बीच का खम्भा ऊँचा रखा गया।",
    # EN: The line snapped straight — the Earth curves.
    "रेखा सीधी हो गई — पृथ्वी मुड़ती है।",
]
CAPS = [
    ("1838 — three flags, one 'STRAIGHT' claim", "STRAIGHT"),
    ("1870 — the same test, the middle pole RAISED", "RAISED"),
    ("The line snaps straight — the EARTH curves", "EARTH"),
]
# poles: (base_x, base_y, top_y_true) — B's marker starts sagged, rises to true
POLES = [(620, 920, 640), (880, 660, 515), (1010, 492, 452)]
SAG = 41

def _compute(durs):
    starts, vo_end = layout(durs, gap=0.30)
    return starts, vo_end

try:
    _durs0 = json.load(open(os.path.join(HERE, f"{TAG}_vo.json")))["durs"]
except Exception:
    _durs0 = [3.0, 3.8, 2.4]
STARTS, VO_END = _compute(_durs0)

def draw(t):
    s1, s2, s3 = STARTS
    img = Image.new("RGB", (W, H), SKY_B)
    d = ImageDraw.Draw(img, "RGBA")
    for yy in range(0, 420, 8):
        d.rectangle([0, yy, W, yy + 8], fill=tuple(
            int(SKY_T[i] + (SKY_B[i] - SKY_T[i]) * yy / 420) for i in range(3)) + (255,))
    # distant treeline
    d.rectangle([0, 388, W, 424], fill=(92, 116, 84, 255))
    for x in range(20, W, 90):
        d.ellipse([x, 372, x + 54, 410], fill=(92, 116, 84, 255))
    # banks + canal in perspective
    d.polygon([(0, 424), (830, 424), (200, 1080), (0, 1080)], fill=BANK + (255,))
    d.polygon([(1090, 424), (W, 424), (W, 1080), (1720, 1080)], fill=BANK_D + (255,))
    d.polygon([(830, 424), (1090, 424), (1720, 1080), (200, 1080)], fill=WATER + (255,))
    # moving water dashes (the scene lives)
    for k in range(26):
        p = ((k * 0.618) + t * 0.05 * (1 + (k % 3) * 0.3)) % 1.0
        y = 440 + p * 620
        half = 130 + p * 720
        cx = 960 + ((k * 197) % 300 - 150) * (0.3 + p)
        ln = 26 + p * 60
        d.line([cx - ln / 2, y, cx + ln / 2, y], fill=(230, 244, 250, int(40 + 60 * p)), width=3)
    # towpath line
    d.line([830, 424, 200, 1080], fill=(70, 88, 60, 255), width=5)
    d.line([1090, 424, 1720, 1080], fill=(60, 78, 54, 255), width=5)
    # ---- poles + flags + markers ----
    rise = ease_inout(min(max((t - (s2 + 0.9)) / 1.1, 0.0), 1.0)) if t > s2 + 0.9 else 0.0
    tops = []
    for i, (bx, by, top) in enumerate(POLES):
        sag = SAG if i == 1 else 0
        marker_y = top + sag * (1 - rise) if i == 1 else top
        wdt = 13 - i * 3
        d.rectangle([bx - wdt // 2, marker_y, bx + wdt // 2, by], fill=(60, 48, 36, 255))
        # flag flutters at the pole top
        fl = int(5 * math.sin(t * 6 + i * 1.7))
        fw = 64 - i * 13
        d.polygon([(bx + wdt // 2, marker_y), (bx + wdt // 2 + fw, marker_y + 12 + fl),
                   (bx + wdt // 2, marker_y + 26)], fill=RED + (255,))
        # marker disc at the sight height
        d.ellipse([bx - 13, marker_y - 13, bx + 13, marker_y + 13], fill=GOLD + (255,),
                  outline=(20, 20, 20, 255), width=2)
        tops.append((bx, marker_y))
    # ---- sight line through the markers ----
    (ax, ay), (bx2, by2), (cx2, cy2) = tops
    if rise < 1.0:
        # straight reference (faint, dashed) + the sagging reading (solid)
        for x in range(ax, cx2, 34):
            yy = ay + (cy2 - ay) * (x - ax) / (cx2 - ax)
            d.line([x, yy, x + 18, yy], fill=(255, 255, 255, 120), width=3)
        d.line([ax, ay, bx2, by2], fill=(255, 255, 255, 255), width=4)
        d.line([bx2, by2, cx2, cy2], fill=(255, 255, 255, 255), width=4)
    else:
        d.line([ax, ay, cx2, cy2], fill=GOLD + (255,), width=5)
    # ---- REFRACTION side tag during line 2, until the rise completes ----
    if s2 + 0.20 < t and rise < 1.0:
        ap = ease_out(min((t - s2 - 0.20) / 0.4, 1.0))
        bx, by = 1330, 430
        anchor = (tops[1][0] + 16, tops[1][1] + 6)
        d.line([anchor[0], anchor[1], bx + 180, by + 52], fill=(30, 28, 24, 230), width=3)
        d.ellipse([anchor[0] - 7, anchor[1] - 7, anchor[0] + 7, anchor[1] + 7], fill=RED + (255,))
        d.rounded_rectangle([bx, by, bx + 470, by + 108], radius=12,
                            fill=(250, 244, 226, int(255 * ap)), outline=(40, 36, 30, 255), width=3)
        if ap > 0.6:
            ctext(d, bx + 235, by + 14, "REFRACTION", F(36), RED, 1)
            ctext(d, bx + 235, by + 62, "THE HIDDEN FLAW", FB(26), (40, 36, 30), 1)
    # ---- date chip + closing banner ----
    pc.date_chip(d, "1870 — THE RE-RUN" if t >= s2 else "1838 — THE FIRST TEST")
    if t > s3 + 0.30:
        p = ease_out(min((t - s3 - 0.30) / 0.45, 1.0))
        bw = int(620 * p)
        d.rounded_rectangle([W // 2 - bw // 2, 806, W // 2 + bw // 2, 884], radius=14,
                            fill=(14, 17, 28, 240), outline=GOLD + (255,), width=2)
        if p > 0.6:
            ctext(d, W // 2, 824, "THE EARTH CURVES", F(42), GOLD, 2)
    return vignette_l(img)

def tighten(tag):
    """House TP discipline: if the master measures above -1.5 dBTP, trim the
    audio by the excess and re-limit (the s52 'TP-tightening pass')."""
    master = os.path.join(HERE, f"{tag}.mp4")
    q = pc.qc(master, tag)
    if q["tp"] > -1.5:
        gain = -1.55 - q["tp"]
        tmp = os.path.join(HERE, f"{tag}_tp.mp4")
        pc.run(f"ffmpeg -y -loglevel error -i {master} -af volume={gain:.2f}dB,"
               f"alimiter=limit=0.80:level=false -c:v copy -c:a aac -b:a 160k "
               f"-movflags +faststart {tmp}")
        os.replace(tmp, master)
        review = os.path.join(HERE, f"{tag}_review.mp4")
        pc.run(f"ffmpeg -y -loglevel error -i {master} -c:v libx264 -profile:v main -crf 26 "
               f"-preset veryfast -pix_fmt yuv420p -c:a aac -b:a 128k -movflags +faststart {review}")
        q = pc.qc(master, tag)
        print(f"{tag} TP-tightened by {gain:.2f} dB -> LUFS={q['lufs']:.2f} TP={q['tp']:.2f}")
    return q

def main():
    global STARTS, VO_END
    vo = synth_vo(LINES, TAG)
    STARTS, VO_END = _compute(vo["durs"])
    starts = STARTS
    total = VO_END + 0.95
    caps = Caps()
    for s, dur, (txt, hot) in zip(starts, vo["durs"], CAPS):
        caps.add(s, s + dur + 0.25, txt, hot)
    sfx = [("whoosh", 0.05, 0.5), ("click", starts[1] + 0.20, 0.7),
           ("riser", starts[1] + 0.9, 0.55), ("hit", starts[1] + 2.0, 0.85),
           ("hit", starts[2] + 0.30, 0.95)]
    audio = build_track(total, vo["arrays"], starts, seed=67,
                        music_freqs=(55.0, 82.4, 110.0), sfx=sfx)

    def full(t):
        img = draw(t)
        caps.draw(img, t)
        return img

    finish(TAG, total, full, audio)
    q = tighten(TAG)
    print(TAG, "starts", [round(s, 2) for s in starts], "total", round(total, 2), "QC", q)

if __name__ == "__main__":
    main()
