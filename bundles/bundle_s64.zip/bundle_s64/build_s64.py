# -*- coding: utf-8 -*-
"""Skill #64 — The interview audit (the rebuttal of record).
Route: plain document-highlight (documents carry the rebuttal), CPU.
Fresh original showcase: the subject's own fresh claim is played as a quote
card in his words, then audited against his own bank certificate, read past
its headline — the highlight sweeps the interest clause as it is spoken.
English on-screen text, locked Hindi VO (tts speed 95, natural speed,
pre-generated in this bundle), documents full-front with the highlight ON
the paper, callouts BESIDE elements in a clean side box with a leader line,
-14 LUFS master. The official is unnamed and the certificate is a drawn
exhibit — the showcase proves the grammar, not a charge against a person.
Lane needs: python3 + Pillow + numpy, ffmpeg. No network, no tts.
"""
import os, sys, math
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "house"))
from PIL import Image, ImageDraw, ImageFilter, ImageChops
import proto_common as pc
from proto_common import (W, H, F, tw, ctext, ease_out, GOLD, GOLD2, WHITE,
                          AMBER, TEAL, Caps, synth_vo, layout, build_track,
                          finish, solid, vignette_l)
from lab_common import FB, FS, FSB, FM

pc.LAB = HERE
TAG = "s64"
RED = (198, 44, 32)
PAPER = (240, 234, 218)
INK = (36, 34, 38)
FAUX = (108, 100, 84)
RULE = (140, 118, 70)

LINES = [
    # EN: On camera he said — I did not take even one rupee.
    "उन्होंने कैमरे पर कहा — मैंने एक रुपया नहीं लिया।",
    # EN: Now look at his certificate — the interest line.
    "अब उनका सर्टिफ़िकेट देखिए — ब्याज की लाइन।",
    # EN: The paper says more than the statement.
    "काग़ज़ बयान से ज़्यादा कहता है।",
]
CAPS = [
    ("On camera he said — I never took a single RUPEE", "RUPEE"),
    ("Now read his own bank certificate — the INTEREST line", "INTEREST"),
    ("The PAPER says more than the statement", "PAPER"),
]

# certificate geometry (frame coords when settled)
CX, CY, CW, CH = 120, 120, 1150, 780
ROWS = [
    ("ACCOUNT", "FAMILY TRUST — 0047 2210"),
    ("OPENED", "14 MARCH 2019"),
    ("PRINCIPAL ON DEPOSIT", "Rs. 18,00,000"),
]
INT_LABEL, INT_VALUE = "INTEREST CREDITED", "Rs. 4,72,318"
INT_Y = 540          # sheet-local y of the interest row
ROW_Y0, ROW_DY = 290, 78

def side_box(d, bx, by, title, lines, anchor, title_col=GOLD, wbox=470):
    """Callout label BESIDE the element, clean box + thin leader line."""
    hh = 58 + 44 * len(lines)
    edge = bx if anchor[0] < bx else bx + wbox
    d.line([anchor[0], anchor[1], edge, by + hh // 2], fill=(255, 255, 255, 200), width=3)
    d.ellipse([anchor[0] - 7, anchor[1] - 7, anchor[0] + 7, anchor[1] + 7], fill=GOLD + (255,))
    d.rounded_rectangle([bx, by, bx + wbox, by + hh], radius=14, fill=(8, 10, 14, 228),
                        outline=title_col + (255,), width=3)
    d.text((bx + 24, by + 12), title, font=F(34), fill=title_col + (255,))
    yy = by + 58
    for ln in lines:
        d.text((bx + 24, yy), ln, font=F(30), fill=WHITE + (255,)); yy += 44
    return hh

def backdrop():
    img = solid((16, 18, 24))
    glow = Image.new("RGB", (W, H), (0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse([W // 2 - 720, 40, W // 2 + 720, 1040], fill=(52, 44, 26))
    glow = glow.filter(ImageFilter.GaussianBlur(170))
    img = ImageChops.add(img, glow)
    return vignette_l(img)

BACK = backdrop()

def certificate(hl):
    """Full-front bank certificate; hl in [0,1] sweeps the interest line."""
    img = Image.new("RGB", (CW, CH), PAPER)
    d = ImageDraw.Draw(img, "RGBA")
    d.rectangle([20, 20, CW - 20, CH - 20], outline=RULE + (255,), width=2)
    d.rectangle([30, 28, CW - 30, 70], fill=(46, 52, 74, 255))
    ctext(d, CW // 2, 40, "NATIONAL BANK", FB(28), (238, 230, 205), 1)
    ctext(d, CW // 2, 92, "CERTIFICATE OF DEPOSIT", FSB(52), INK, 1)
    ctext(d, CW // 2, 168, "Issued to the account holder — a true copy of the bank's record",
          FS(26), FAUX, 0)
    d.line([70, 224, CW - 70, 224], fill=RULE + (255,), width=2)
    for i, (k, v) in enumerate(ROWS):
        y = ROW_Y0 + i * ROW_DY
        d.text((84, y), k, font=FM(30), fill=FAUX + (255,))
        d.text((560, y), v, font=FM(33), fill=INK + (255,))
        d.line([84, y + 52, CW - 84, y + 52], fill=(190, 178, 148, 255), width=1)
    # the interest row — the clause the interview never mentioned
    y = INT_Y
    if hl > 0:
        lw_, _ = tw(d, INT_VALUE, FM(38), 0)
        d.rectangle([548, y - 8, 548 + int((lw_ + 24) * hl), y + 56],
                    fill=(255, 196, 54, 130))
    d.text((84, y), INT_LABEL, font=FM(30), fill=(140, 40, 30, 255))
    d.text((560, y), INT_VALUE, font=FM(38), fill=(140, 40, 30, 255))
    d.line([84, y + 66, CW - 84, y + 66], fill=(190, 178, 148, 255), width=1)
    ctext(d, CW // 2, CH - 92, "This certificate is issued at the holder's own request.",
          FS(25), FAUX, 0)
    return img

def stamp_layer(scale, rot, alpha):
    sw, sh = 860, 176
    img = Image.new("RGBA", (sw, sh), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([10, 10, sw - 10, sh - 10], radius=16, outline=RED + (alpha,), width=12)
    ctext(d, sw // 2, 48, "THE PAPER SAYS MORE", F(76), RED + (alpha,), 2)
    img = img.resize((int(sw * scale), int(sh * scale)), Image.LANCZOS)
    return img.rotate(rot, resample=Image.BICUBIC, expand=True)


def tighten(tag):
    """House TP discipline: if the master measures above -1.5 dBTP, trim the
    audio by the excess and re-limit (the s52 'TP-tightening pass')."""
    master = os.path.join(HERE, f"{tag}.mp4")
    q = pc.qc(master, tag)
    if q["tp"] > -1.5:
        gain = -1.55 - q["tp"]
        tmp = os.path.join(HERE, f"{tag}_tp.mp4")
        pc.run(f"ffmpeg -y -loglevel error -i {master} -af volume={gain:.2f}dB,"
               f"alimiter=limit=0.80:level=false -c:v copy -c:a aac -b:a 160k "
               f"-movflags +faststart {tmp}")
        os.replace(tmp, master)
        review = os.path.join(HERE, f"{tag}_review.mp4")
        pc.run(f"ffmpeg -y -loglevel error -i {master} -c:v libx264 -profile:v main "
               f"-crf 26 -preset veryfast -pix_fmt yuv420p -c:a aac -b:a 128k "
               f"-movflags +faststart {review}")
        q = pc.qc(master, tag)
        print(f"{tag} TP-tightened by {gain:.2f} dB -> LUFS={q['lufs']:.2f} TP={q['tp']:.2f}")
    return q

# ---------------------------------------------------------------- build
def main():
    vo = synth_vo(LINES, TAG)
    starts, vo_end = layout(vo["durs"], gap=0.30)
    total = vo_end + 0.85
    s1, s2, s3 = starts
    stamp_t = s3 + 0.30
    caps = Caps()
    for s, dur, (txt, hot) in zip(starts, vo["durs"], CAPS):
        caps.add(s, s + dur + 0.25, txt, hot)
    audio = build_track(total, vo["arrays"], starts, seed=13,
                        sfx=[("whoosh", 0.10, 0.7), ("whoosh", s2 - 0.1, 0.8),
                             ("hit", stamp_t, 1.0)])

    def draw(t):
        img = BACK.copy()
        d = ImageDraw.Draw(img, "RGBA")
        if t < s2 - 0.15:
            # ---- beat A: the claim, in his own words, on a quote card
            p = ease_out(min(t / 0.7, 1.0))
            qw, qh = 1240, 330
            qx, qy = (W - qw) // 2, 300 + int((1 - p) * 120)
            d.rounded_rectangle([qx + 14, qy + 16, qx + qw + 14, qy + qh + 16],
                                radius=18, fill=(0, 0, 0, 120))
            d.rounded_rectangle([qx, qy, qx + qw, qy + qh], radius=18,
                                fill=(12, 14, 20, 242), outline=GOLD + (255,), width=3)
            d.rectangle([qx, qy, qx + 14, qy + qh], fill=GOLD + (255,))
            d.rectangle([qx + 44, qy + 36, qx + 66, qy + 58], fill=RED + (255,))
            d.text((qx + 80, qy + 28), "ON CAMERA — HIS OWN WORDS", font=F(30),
                   fill=(255, 150, 140, 255))
            ctext(d, W // 2, qy + 108, "\u201CI NEVER TOOK A RUPEE.\u201D", FSB(66), WHITE, 2)
            ctext(d, W // 2, qy + 226, "— THE OFFICIAL, IN HIS OWN INTERVIEW, LAST WEEK",
                  FB(30), (210, 200, 175), 1)
            return img
        # ---- beat B/C: the certificate rises full-front; highlight sweeps
        lt = t - (s2 - 0.15)
        p = ease_out(min(lt / 0.75, 1.0))
        creep = 1.0 + 0.012 * min(max((t - s2) / max(total - s2, 0.01), 0.0), 1.0)
        cw2, ch2 = int(CW * creep), int(CH * creep)
        hl = min(max((t - s2) / max(vo["durs"][1], 0.01), 0.0), 1.0) if t >= s2 else 0.0
        cert = certificate(hl).resize((cw2, ch2), Image.LANCZOS)
        cx = CX + (CW - cw2) // 2
        cy = CY + int((1 - p) * 420)
        d.rectangle([cx + 16, cy + ch2 - 2, cx + cw2 + 26, cy + ch2 + 12], fill=(0, 0, 0, 110))
        img.paste(cert, (cx, cy))
        d = ImageDraw.Draw(img, "RGBA")
        if t >= s2 + 0.55:
            ax, ay = cx + int(852 * creep), cy + int((INT_Y + 24) * creep)
            side_box(d, 1360, 600, "THE INTEREST LINE",
                     ["Rs. 4,72,318 credited",
                      "in a single year —",
                      "on his own paper."],
                     anchor=(ax, ay), wbox=500)
        if t >= stamp_t:
            st = t - stamp_t
            sc = 1.0 + 0.9 * math.exp(-st * 14) * (1 if st < 0.22 else 0.25)
            shake = int(7 * math.exp(-st * 10)) if st < 0.4 else 0
            st_img = stamp_layer(sc, -8, 255)
            img.paste(st_img, (cx + 70 + shake, cy + int(616 * creep)), st_img)
        return img

    def full(t):
        img = draw(t)
        caps.draw(img, t)
        return img

    finish(TAG, total, full, audio)
    q = tighten(TAG)
    print(TAG, "starts", [round(s, 2) for s in starts], "total", round(total, 2), "QC", q)

if __name__ == "__main__":
    main()
