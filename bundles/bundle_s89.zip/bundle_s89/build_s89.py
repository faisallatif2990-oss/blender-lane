# -*- coding: utf-8 -*-
"""Skill #89 — The satire pivot.
Route: plain route — scene edit (two-register cut), CPU. Fresh
original showcase performed in two announced registers. Register
one, deadpan: a golden statue on its plinth while the snow falls —
and on cue, mid-line, the snow STOPS in mid-air and hangs there,
held, exactly as the official myth claims it did on the day of the
leader's passing. A card then slams the pivot by name — "ENOUGH.
NOW SERIOUSLY." — the scene cuts to black, and register two is a
witness carrying the serious half: a defector's own words typing
out over the black. English on-screen text, locked Hindi VO (tts
speed 95, natural speed, pre-generated in this bundle), clean small
captions with gold hot-words, -14 LUFS master.
Lane needs: python3 + Pillow + numpy, ffmpeg. No network, no tts.
"""
import os, sys, math, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "house"))
from PIL import Image, ImageDraw, ImageFilter, ImageChops
import numpy as np
import proto_common as pc
from proto_common import (W, H, F, tw, ctext, ease_out, ease_inout, GOLD,
                          WHITE, Caps, synth_vo, layout, build_track,
                          finish, solid, vignette_l)
from lab_common import FB, FS, FSB, FM, FMB

pc.LAB = HERE
TAG = "s89"
RED = (205, 52, 40)
GOLDD = (196, 150, 44)
GOLDL = (255, 214, 90)
STONE = (56, 62, 84)
SLATE = (150, 158, 175)

LINES = [
    # EN: That day even the snow stopped — the leader was passing.
    "उस दिन बर्फ़ भी रुक गई थी — नेता गुज़र रहे थे।",
    # EN: Enough — joking is over; now, seriously.
    "बस, मज़ाक बहुत हुआ — अब सचमुच।",
    # EN: These are the words of a man who came from there — we did not even know we had rights.
    "वहाँ से आए एक इंसान के शब्द हैं — हमें अपने हक़ का पता ही नहीं था।",
]
CAPS = [
    ("That day even the SNOW stopped — the leader passed", "SNOW"),
    ("ENOUGH joking — now, seriously", "ENOUGH"),
    ("A defector's own WORDS — 'we never knew our rights'", "WORDS"),
]
QUOTE = ['"WE', "DID", "NOT", "EVEN", "KNOW", "WE", "HAD", "RIGHTS.\""]

def backdrop():
    grad = np.zeros((H, W, 3), dtype=np.uint8)
    top = np.array([10, 14, 34], dtype=float)
    bot = np.array([26, 32, 60], dtype=float)
    for y in range(H):
        grad[y, :, :] = (top + (bot - top) * (y / H)).astype(np.uint8)
    img = Image.fromarray(grad, "RGB")
    glow = Image.new("RGB", (W, H), (0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse([560, 180, 1360, 900], fill=(52, 40, 12))
    glow = glow.filter(ImageFilter.GaussianBlur(160))
    img = ImageChops.add(img, glow)
    d = ImageDraw.Draw(img, "RGBA")
    # distant rooftops
    rng = np.random.default_rng(89)
    x = 0
    while x < W:
        bw = int(rng.integers(120, 300)); bh = int(rng.integers(60, 150))
        d.rectangle([x, 806 - bh, x + bw, 806], fill=(7, 9, 18, 255))
        for _ in range(bw // 34):
            wx = x + int(rng.integers(8, max(10, bw - 18)))
            wy = 806 - bh + int(rng.integers(10, max(12, bh - 16)))
            if rng.random() < 0.5:
                d.rectangle([wx, wy, wx + 7, wy + 10], fill=(255, 200, 90, 130))
        x += bw + int(rng.integers(6, 30))
    d.rectangle([0, 806, W, H], fill=(15, 19, 36, 255))
    d.line([0, 806, W, 806], fill=(40, 48, 74, 255), width=2)
    return vignette_l(img)

BACK = backdrop()

def statue(d):
    # plinth + steps
    d.rectangle([820, 776, 1100, 806], fill=STONE + (255,))
    d.rectangle([848, 700, 1072, 776], fill=(64, 71, 96, 255))
    d.rectangle([876, 636, 1044, 700], fill=STONE + (255,))
    # robed figure: body trapezoid, head, raised arm
    d.polygon([(918, 452), (1002, 452), (1040, 636), (880, 636)], fill=GOLDD + (255,))
    d.polygon([(918, 452), (1002, 452), (1012, 540), (908, 540)], fill=(214, 168, 58, 255))
    d.ellipse([928, 384, 992, 448], fill=GOLDD + (255,))
    d.line([996, 478, 1078, 402], fill=GOLDD + (255,), width=21)
    d.line([924, 478, 884, 560], fill=GOLDD + (255,), width=19)
    d.line([918, 452, 908, 540], fill=GOLDL + (160,), width=4)
    d.line([880, 636, 1040, 636], fill=GOLDL + (120,), width=3)

_rng = np.random.default_rng(7)
FLAKES = [(float(_rng.integers(0, W)), float(_rng.integers(0, H)),
           float(_rng.uniform(1.4, 3.4)), float(_rng.uniform(38, 92)),
           float(_rng.uniform(0, 6.28))) for _ in range(240)]

def _compute(durs):
    starts, vo_end = layout(durs, gap=0.30)
    return starts, vo_end

try:
    _durs0 = json.load(open(os.path.join(HERE, f"{TAG}_vo.json")))["durs"]
except Exception:
    _durs0 = [3.4, 2.7, 4.8]
STARTS, VO_END = _compute(_durs0)
DURS = _durs0
FREEZE_T = STARTS[0] + DURS[0] - 0.30

def draw(t):
    s1, s2, s3 = STARTS
    wipe = t >= s2 + 1.25
    if wipe:
        img = Image.new("RGB", (W, H), (4, 4, 6))
    else:
        img = BACK.copy()
    d = ImageDraw.Draw(img, "RGBA")
    if not wipe:
        statue(d)
        # snowfall — falls until FREEZE_T, then hangs in mid-air
        teff = min(t, FREEZE_T)
        for (x0, y0, r, sp, ph) in FLAKES:
            y = (y0 + sp * teff) % H
            x = x0 + math.sin(teff * 0.7 + ph) * 14
            a = 200 if t < FREEZE_T else 235
            d.ellipse([x - r, y - r, x + r, y + r], fill=(235, 240, 250, a))
        if t >= FREEZE_T and t < s2 + 1.25:
            ctext(d, W // 2, 120, "THE SNOW, HOLDING ITS BREATH", FM(28), SLATE, 0)
        if t > 0.8:
            ctxt = "OFFICIAL ACCOUNT — THE DAY OF THE PASSING"
            cw, _bb = tw(d, ctxt, FM(25), 0)
            d.rounded_rectangle([56, 56, 56 + cw + 28, 56 + 44], radius=8, fill=(0, 0, 0, 170))
            d.text((70, 66), ctxt, font=FM(25), fill=SLATE + (230,))
    # ---- the pivot, named (line 2) ----
    pt = s2 + 0.45
    if t >= pt and t < s3 + 0.35:
        p = ease_out(min((t - pt) / 0.22, 1.0))
        cw2, ch2 = int(1180 * (1.25 - 0.25 * p)), int(250 * (1.25 - 0.25 * p))
        cx, cy = W // 2, 500
        card = Image.new("RGBA", (cw2, ch2), (0, 0, 0, 0))
        cd = ImageDraw.Draw(card)
        cd.rectangle([4, 4, cw2 - 4, ch2 - 4], fill=(5, 5, 7, 255), outline=RED + (255,), width=5)
        f1 = F(int(84 * (1.25 - 0.25 * p)))
        ctext(cd, cw2 // 2, int(ch2 * 0.16), "ENOUGH.", f1, WHITE + (255,), 1)
        ctext(cd, cw2 // 2, int(ch2 * 0.58), "NOW SERIOUSLY.", f1, GOLD + (255,), 1)
        img.paste(card, (cx - cw2 // 2, cy - ch2 // 2), card)
        d = ImageDraw.Draw(img, "RGBA")
    # ---- the witness types over black (line 3) ----
    if t >= s3:
        d.text((120, 268), "IN HIS OWN WORDS — A MAN WHO LEFT:", font=FM(30),
               fill=SLATE + (255,))
        nwords = len(QUOTE)
        shown = int(nwords * min(max((t - s3 - 0.25) / (DURS[2] * 0.82), 0.0), 1.0))
        line1 = " ".join(QUOTE[:5]); line2 = " ".join(QUOTE[5:])
        got1 = " ".join(QUOTE[:min(shown, 5)])
        got2 = " ".join(QUOTE[5:shown]) if shown > 5 else ""
        if got1:
            ctext(d, W // 2, 420, got1, FS(66), WHITE, 1)
        if got2:
            ctext(d, W // 2, 520, got2, FS(66), WHITE, 1)
        if shown >= nwords and (t * 2) % 1 < 0.6:
            lw, _ = tw(d, line2, FS(66), 1)
            d.rectangle([W // 2 + lw // 2 + 16, 528, W // 2 + lw // 2 + 40, 580],
                        fill=GOLD + (230,))
    return img

def tighten(tag):
    """House TP discipline: if the master measures above -1.5 dBTP, trim the
    audio by the excess and re-limit (the s52 'TP-tightening pass')."""
    master = os.path.join(HERE, f"{tag}.mp4")
    q = pc.qc(master, tag)
    if q["tp"] > -1.5:
        gain = -1.55 - q["tp"]
        tmp = os.path.join(HERE, f"{tag}_tp.mp4")
        pc.run(f"ffmpeg -y -loglevel error -i {master} -af volume={gain:.2f}dB,"
               f"alimiter=limit=0.80:level=false -c:v copy -c:a aac -b:a 160k "
               f"-movflags +faststart {tmp}")
        os.replace(tmp, master)
        review = os.path.join(HERE, f"{tag}_review.mp4")
        pc.run(f"ffmpeg -y -loglevel error -i {master} -c:v libx264 -profile:v main -crf 26 "
               f"-preset veryfast -pix_fmt yuv420p -c:a aac -b:a 128k -movflags +faststart {review}")
        q = pc.qc(master, tag)
        print(f"{tag} TP-tightened by {gain:.2f} dB -> LUFS={q['lufs']:.2f} TP={q['tp']:.2f}")
    return q

def main():
    global STARTS, VO_END, DURS, FREEZE_T
    vo = synth_vo(LINES, TAG)
    DURS = vo["durs"]
    STARTS, VO_END = _compute(DURS)
    FREEZE_T = STARTS[0] + DURS[0] - 0.30
    starts = STARTS
    total = VO_END + 0.95
    caps = Caps()
    for s, dur, (txt, hot) in zip(starts, DURS, CAPS):
        caps.add(s, s + dur + 0.25, txt, hot)
    sfx = [("click", FREEZE_T, 0.7), ("hit", starts[1] + 0.45, 1.0)]
    sfx += [("click", starts[2] + 0.25 + i * (DURS[2] * 0.82 / len(QUOTE)), 0.32)
            for i in range(len(QUOTE))]
    audio = build_track(total, vo["arrays"], starts, seed=89,
                        music_freqs=(55.0, 65.4, 82.4), sfx=sfx)

    def full(t):
        img = draw(t)
        caps.draw(img, t)
        return img

    finish(TAG, total, full, audio)
    q = tighten(TAG)
    print(TAG, "starts", [round(s, 2) for s in starts], "total", round(total, 2), "QC", q)

if __name__ == "__main__":
    main()
