#!/bin/sh
# Skill #89 — lane build: produces s89.mp4 + s89_review.mp4 in this folder.
# Needs: python3 with Pillow + numpy, and ffmpeg/ffprobe on PATH. VO is
# pre-generated (s89_vo_*.mp3 in this folder) — no network, no tts needed.
set -e
cd "$(dirname "$0")"
python3 -c "import PIL, numpy" 2>/dev/null || { echo 'MISSING: python3 Pillow/numpy'; exit 1; }
command -v ffmpeg >/dev/null || { echo 'MISSING: ffmpeg'; exit 1; }
python3 build_s89.py
