# -*- coding: utf-8 -*-
"""Skill #77 — The vindicated re-upload.
Route: plain route — footage/document edit, CPU. Fresh original showcase:
a 1962 documentary short, "THE RIVER'S TESTIMONY", sits frozen inside a
player frame under a red REMOVED stamp; a court order page rises
full-front with its key line highlighted; the stamp flips to CLEARED and
the old film thaws into motion inside the frame. The film inside the
player is real public-domain archive footage (assets/oldfilm_s77.mp4 —
"The Battle of the Somme", 1916, public domain; see assets/CREDIT.txt),
used as the suppressed film. English on-screen text, locked Hindi VO
(tts speed 95, natural speed, pre-generated in this bundle), clean small
captions with gold hot-words, -14 LUFS master.
Lane needs: python3 + Pillow + numpy, ffmpeg. No network, no tts.
"""
import os, sys, math, json, subprocess
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "house"))
from PIL import Image, ImageDraw, ImageFilter, ImageEnhance
import numpy as np
import proto_common as pc
from proto_common import (W, H, F, tw, ctext, ease_out, ease_inout, GOLD,
                          WHITE, Caps, synth_vo, layout, build_track,
                          finish, solid, vignette_l)
from lab_common import FB, FS, FSB, FM, FMB

pc.LAB = HERE
TAG = "s77"
RED = (205, 52, 40)
GREEN = (46, 170, 92)
PAPER = (238, 231, 214)
INK = (40, 36, 30)
FAUX = (120, 110, 90)
ASSET = os.path.join(HERE, "assets", "oldfilm_s77.mp4")

LINES = [
    # EN: This film was once removed — without any reason given.
    "यह फ़िल्म एक बार हटा दी गई थी — बिना कोई वजह बताए।",
    # EN: Then came the court's order — no basis for the ban.
    "फिर अदालत का आदेश आया — प्रतिबंध का कोई आधार नहीं।",
    # EN: Today it plays again — exactly as it was made.
    "आज यह फिर चलती है — बिल्कुल वैसी, जैसी बनी थी।",
]
CAPS = [
    ("This film was REMOVED once — no reason given", "REMOVED"),
    ("The COURT order: no ground for the ban", "COURT"),
    ("Today it plays again — exactly as MADE", "MADE"),
]

# player geometry
PX, PY, PW, PH = 250, 140, 1420, 800
IX, IY, IW, IH = PX + 18, PY + 74, PW - 36, PH - 128   # film window

class Grabber:
    """Sequential raw-frame reader over the bundled film; frame(i) returns
    the i-th frame (0-based) at the film-window size, holding the last
    frame when i stops advancing (the freeze)."""
    def __init__(self, path):
        cmd = (f"ffmpeg -v error -i {path} -vf fps=24,scale={IW}:{IH}:"
               f"force_original_aspect_ratio=increase,crop={IW}:{IH} "
               f"-f rawvideo -pix_fmt rgb24 -")
        self.pr = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        self.idx = -1; self.cur = None; self.n = IW * IH * 3
    def frame(self, i):
        while self.idx < i:
            buf = self.pr.stdout.read(self.n)
            if len(buf) < self.n:
                break
            self.cur = Image.frombytes("RGB", (IW, IH), buf)
            self.idx += 1
        return self.cur

def stamp_img(text, col, w=560, h=170, rot=-12, fs=84):
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([8, 8, w - 8, h - 8], radius=10, outline=col + (255,), width=9)
    d.rounded_rectangle([24, 24, w - 24, h - 24], radius=6, outline=col + (255,), width=3)
    ctext(d, w // 2, h // 2 - fs // 2 + 2, text, F(fs), col + (255,), 1)
    return img.rotate(rot, resample=Image.BICUBIC, expand=True)

REMOVED = stamp_img("REMOVED", RED)
CLEARED = stamp_img("CLEARED", GREEN, w=470, h=140, rot=8, fs=66)

def court_page():
    """The court order sheet, drawn full-front; returns (image, key-line y)."""
    w, h = 1060, 800
    img = Image.new("RGB", (w, h), PAPER)
    d = ImageDraw.Draw(img, "RGBA")
    d.rectangle([0, 0, w, h], outline=(168, 156, 124), width=4)
    ctext(d, w // 2, 44, "IN THE HIGH COURT", FSB(40), INK, 0)
    ctext(d, w // 2, 102, "ORDER — CIVIL PETITION No. 412 OF 1965", FM(26), FAUX, 0)
    d.line([70, 160, w - 70, 160], fill=INK + (255,), width=3)
    body = [
        "Upon hearing the parties, and upon a viewing",
        "of the film in open court, this Court records",
        "that the objection raised against the film",
        "rests on no provision of law, and that its",
        "continued suppression would serve no public",
        "purpose whatsoever.",
    ]
    yy = 196
    for ln in body:
        d.text((78, yy), ln, font=FS(33), fill=(70, 62, 48, 255)); yy += 52
    key_y = yy + 16
    d.rectangle([58, key_y - 8, w - 58, key_y + 62], fill=(255, 205, 40, 120))
    d.text((78, key_y + 6), "THE COURT FINDS NO GROUND FOR THE BAN",
           font=FSB(35), fill=INK + (255,))
    yy = key_y + 108
    for ln in ["The film shall be restored to exhibition",
               "forthwith, in the form in which it was made."]:
        d.text((78, yy), ln, font=FS(33), fill=(70, 62, 48, 255)); yy += 52
    d.text((78, h - 96), "By order of the Court — Registrar", font=FM(25), fill=FAUX + (255,))
    d.ellipse([w - 190, h - 170, w - 70, h - 50], outline=(150, 60, 50, 200), width=4)
    ctext(d, w - 130, h - 128, "SEAL", FM(22), (150, 60, 50, 200), 0)
    return img, key_y + 30

PAGE, KEY_Y = court_page()

def backdrop():
    img = solid((13, 15, 24))
    glow = Image.new("RGB", (W, H), (0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse([300, 60, 1620, 1020], fill=(30, 34, 56))
    glow = glow.filter(ImageFilter.GaussianBlur(150))
    from PIL import ImageChops
    img = ImageChops.add(img, glow)
    return vignette_l(img)

BACK = backdrop()

def _compute(durs):
    starts, vo_end = layout(durs, gap=0.30)
    return starts, vo_end

try:
    _durs0 = json.load(open(os.path.join(HERE, f"{TAG}_vo.json")))["durs"]
except Exception:
    _durs0 = [3.0, 3.2, 2.8]
STARTS, VO_END = _compute(_durs0)
FREEZE_SRC = 72          # hold the film at its 3.0 s frame while "removed"
GRAB = None
HELD = {"img": None}

def film_frame(t, total):
    """Film-window image for time t: frozen (graded, dim) until the page
    leaves, then playing from the held frame onward."""
    global GRAB, HELD
    s1, s2, s3 = STARTS
    play_from = s3 + 0.55
    if t < play_from:
        src = FREEZE_SRC
    else:
        src = FREEZE_SRC + int((t - play_from) * 24)
    if GRAB is None:
        GRAB = Grabber(ASSET)
    raw = GRAB.frame(src)
    if raw is None:
        return Image.new("RGB", (IW, IH), (20, 20, 20))
    if t < play_from:
        if HELD["img"] is None or HELD.get("src") != src:
            im = ImageEnhance.Color(raw.copy()).enhance(0.55)
            im = ImageEnhance.Brightness(im).enhance(0.82)
            HELD["img"] = im; HELD["src"] = src
        return HELD["img"]
    return raw

def draw(t):
    s1, s2, s3 = STARTS
    total = VO_END + 0.95
    img = BACK.copy()
    d = ImageDraw.Draw(img, "RGBA")
    cleared = t >= s3 + 0.55
    # ---- player chrome ----
    border = GOLD if cleared else (120, 126, 140)
    d.rounded_rectangle([PX, PY, PX + PW, PY + PH], radius=18, fill=(18, 20, 28, 255),
                        outline=border + (255,), width=3)
    for k, col in enumerate([(230, 90, 80), (240, 190, 80), (90, 200, 120)]):
        d.ellipse([PX + 26 + k * 34, PY + 22, PX + 48 + k * 34, PY + 44], fill=col + (255,))
    d.text((PX + 150, PY + 20), "THE RIVER'S TESTIMONY — 1962", font=FB(30),
           fill=(220, 224, 235, 255))
    # ---- film window ----
    film = film_frame(t, total)
    mask = Image.new("L", (IW, IH), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, IW, IH], radius=10, fill=255)
    img.paste(film, (IX, IY), mask)
    d = ImageDraw.Draw(img, "RGBA")
    # progress bar: frozen at 31% until cleared, then advances
    frac = 0.31 if not cleared else min(0.31 + (t - s3 - 0.55) * 0.055, 0.97)
    d.rounded_rectangle([IX, PY + PH - 40, IX + IW, PY + PH - 28], radius=6, fill=(52, 56, 68, 255))
    d.rounded_rectangle([IX, PY + PH - 40, IX + int(IW * frac), PY + PH - 28], radius=6,
                        fill=(GOLD if cleared else (150, 60, 50)) + (255,))
    # ---- REMOVED stamp (until the flip) ----
    flip = s3 + 0.30
    if t < flip:
        p = ease_out(min(t / 0.4, 1.0))
        st = REMOVED.resize((int(REMOVED.width * (0.6 + 0.4 * p)), int(REMOVED.height * (0.6 + 0.4 * p))),
                            Image.LANCZOS) if p > 0 else None
        if st is not None:
            img.paste(st, (W // 2 - st.width // 2, 420 - st.height // 2), st)
        # pause bars
        d.rounded_rectangle([W // 2 - 52, 640, W // 2 - 16, 736], radius=6, fill=(240, 240, 240, 220))
        d.rounded_rectangle([W // 2 + 16, 640, W // 2 + 52, 736], radius=6, fill=(240, 240, 240, 220))
    elif t < flip + 0.35:
        q = (t - flip) / 0.35
        st = CLEARED.resize((int(CLEARED.width * (1.35 - 0.35 * q)), int(CLEARED.height * (1.35 - 0.35 * q))),
                            Image.LANCZOS)
        img.paste(st, (PX + PW - st.width - 40, PY + 96), st)
        d = ImageDraw.Draw(img, "RGBA")
    else:
        img.paste(CLEARED, (PX + PW - CLEARED.width - 40, PY + 96), CLEARED)
        d = ImageDraw.Draw(img, "RGBA")
    # ---- court page rises full-front during line 2 ----
    page_in = s2 + 0.15
    page_out = s3 + 0.10
    if page_in <= t:
        if t < page_out:
            p = ease_out(min((t - page_in) / 0.6, 1.0))
            py = int(H + 40 - (H - 120) * p)
        else:
            p = ease_inout(min((t - page_out) / 0.5, 1.0))
            py = int(120 + (H + 40 - 120) * p)
        if py < H:
            img.paste(PAGE, (W // 2 - PAGE.width // 2, py))
            d = ImageDraw.Draw(img, "RGBA")
            if t < page_out:
                # callout BESIDE the page, leader line to the key line
                bx, by = 1548, 330
                anchor = (W // 2 + PAGE.width // 2, py + KEY_Y)
                d.line([anchor[0], anchor[1], bx + 160, by + 46], fill=(30, 26, 20, 230), width=3)
                d.ellipse([anchor[0] - 7, anchor[1] - 7, anchor[0] + 7, anchor[1] + 7],
                          fill=RED + (255,))
                d.rounded_rectangle([bx, by, bx + 330, by + 96], radius=10,
                                    fill=(250, 244, 226, 255), outline=INK + (255,), width=3)
                ctext(d, bx + 165, by + 12, "THE ORDER", F(30), (26, 104, 104), 1)
                ctext(d, bx + 165, by + 52, "READ THE LINE", FB(26), INK, 1)
    # ---- date chip ----
    pc.date_chip(d, "SUPPRESSED 1962 — RESTORED TODAY" if cleared else "SUPPRESSED — 1962")
    return img

def tighten(tag):
    """House TP discipline: if the master measures above -1.5 dBTP, trim the
    audio by the excess and re-limit (the s52 'TP-tightening pass')."""
    master = os.path.join(HERE, f"{tag}.mp4")
    q = pc.qc(master, tag)
    if q["tp"] > -1.5:
        gain = -1.55 - q["tp"]
        tmp = os.path.join(HERE, f"{tag}_tp.mp4")
        pc.run(f"ffmpeg -y -loglevel error -i {master} -af volume={gain:.2f}dB,"
               f"alimiter=limit=0.80:level=false -c:v copy -c:a aac -b:a 160k "
               f"-movflags +faststart {tmp}")
        os.replace(tmp, master)
        review = os.path.join(HERE, f"{tag}_review.mp4")
        pc.run(f"ffmpeg -y -loglevel error -i {master} -c:v libx264 -profile:v main -crf 26 "
               f"-preset veryfast -pix_fmt yuv420p -c:a aac -b:a 128k -movflags +faststart {review}")
        q = pc.qc(master, tag)
        print(f"{tag} TP-tightened by {gain:.2f} dB -> LUFS={q['lufs']:.2f} TP={q['tp']:.2f}")
    return q

def main():
    global STARTS, VO_END
    vo = synth_vo(LINES, TAG)
    STARTS, VO_END = _compute(vo["durs"])
    starts = STARTS
    total = VO_END + 0.95
    caps = Caps()
    for s, dur, (txt, hot) in zip(starts, vo["durs"], CAPS):
        caps.add(s, s + dur + 0.25, txt, hot)
    sfx = [("hit", 0.25, 0.9), ("whoosh", starts[1] + 0.15, 0.6),
           ("hit", starts[2] + 0.30, 1.0), ("whoosh", starts[2] + 0.55, 0.5)]
    audio = build_track(total, vo["arrays"], starts, seed=77, sfx=sfx)

    def full(t):
        img = draw(t)
        caps.draw(img, t)
        return img

    finish(TAG, total, full, audio)
    q = tighten(TAG)
    print(TAG, "starts", [round(s, 2) for s in starts], "total", round(total, 2), "QC", q)

if __name__ == "__main__":
    main()
