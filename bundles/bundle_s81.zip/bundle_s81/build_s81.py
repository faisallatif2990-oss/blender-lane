# -*- coding: utf-8 -*-
"""Skill #81 — The series-split deferral.
Route: motionmaxxing — question/seam card choreography, CPU. Fresh
original showcase: a sealed-letter mystery in a fort archive. Three
evidence cards build (THE SEAL / THE INK / THE WITNESS); one huge card
lands — "THE BIGGEST QUESTION — WHO WROTE THE LAST PAGE?"; the frame
splits along a stitched seam stamped "ANSWERED IN PART 2", while a
small compressed-answer card peeks in beneath it, so the deferral reads
as structure, not evasion. English on-screen text, locked Hindi VO
(tts speed 95, natural speed, pre-generated in this bundle), clean
small captions with gold hot-words, -14 LUFS master.
Lane needs: python3 + Pillow + numpy, ffmpeg. No network, no tts.
"""
import os, sys, math, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "house"))
from PIL import Image, ImageDraw, ImageFilter, ImageChops
import numpy as np
import proto_common as pc
from proto_common import (W, H, F, tw, ctext, ease_out, ease_inout, GOLD,
                          WHITE, Caps, synth_vo, layout, build_track,
                          finish, solid, vignette_l)
from lab_common import FB, FS, FSB, FM, FMB

pc.LAB = HERE
TAG = "s81"
RED = (205, 52, 40)
CARD = (26, 29, 44)
CARD_E = (58, 63, 84)

LINES = [
    # EN: Three proofs found — the seal, the ink, and a witness.
    "तीन सबूत मिले — मुहर, स्याही, और एक गवाह।",
    # EN: But the biggest question — who wrote the last page?
    "पर सबसे बड़ा सवाल — आख़िरी पन्ना किसने लिखा?",
    # EN: The answer in part two — today only this: the ink is from 1857, the hand is not the Raja's.
    "जवाब भाग दो में — आज इतना ही: स्याही 1857 की है, हाथ राजा का नहीं।",
]
CAPS = [
    ("THREE proofs — the seal, the ink, a witness", "THREE"),
    ("The BIGGEST question — who wrote the last page?", "BIGGEST"),
    ("Answered in PART 2 — the ink is 1857, not his hand", "PART"),
]
EVID = [("THE SEAL", "WAX — UNBROKEN"), ("THE INK", "IRON-GALL — DATED"),
        ("THE WITNESS", "THE SCRIBE'S SON")]

def backdrop():
    img = solid((14, 16, 30))
    glow = Image.new("RGB", (W, H), (0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse([W // 2 - 780, 80, W // 2 + 780, 940], fill=(40, 38, 78))
    glow = glow.filter(ImageFilter.GaussianBlur(180))
    img = ImageChops.add(img, glow)
    d = ImageDraw.Draw(img, "RGBA")
    for gx in range(90, W - 60, 60):
        for gy in range(70, H - 60, 60):
            d.ellipse([gx, gy, gx + 3, gy + 3], fill=(150, 150, 210, 24))
    return vignette_l(img)

BACK = backdrop()
_rng = np.random.default_rng(81)
DUST = [(int(_rng.integers(0, W)), int(_rng.integers(0, H)), int(_rng.integers(1, 4)),
         float(_rng.uniform(4, 14))) for _ in range(40)]

def _compute(durs):
    starts, vo_end = layout(durs, gap=0.30)
    return starts, vo_end

try:
    _durs0 = json.load(open(os.path.join(HERE, f"{TAG}_vo.json")))["durs"]
except Exception:
    _durs0 = [2.8, 2.8, 4.2]
STARTS, VO_END = _compute(_durs0)

def ev_card(title, sub, w=430, h=210):
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([4, 4, w - 4, h - 4], radius=14, fill=CARD + (255,),
                        outline=CARD_E + (255,), width=2)
    d.rectangle([4, 4, w - 4, 14], fill=GOLD + (255,))
    ctext(d, w // 2, 44, title, F(44), GOLD, 1)
    ctext(d, w // 2, 116, sub, FB(27), (205, 210, 224), 1)
    return img

def draw(t):
    s1, s2, s3 = STARTS
    img = BACK.copy()
    breathe = 0.5 + 0.5 * math.sin(t * 1.7)
    glow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse([W // 2 - 640, 60, W // 2 + 640, 720], fill=(255, 205, 40, int(8 + 12 * breathe)))
    img = Image.alpha_composite(img.convert("RGBA"), glow).convert("RGB")
    d = ImageDraw.Draw(img, "RGBA")
    for x, y, r, sp in DUST:
        yy = (y + t * sp) % H
        d.ellipse([x - r, yy - r, x + r, yy + r], fill=(255, 214, 130, 32))
    # ---- evidence cards build across line 1 ----
    for i, (title, sub) in enumerate(EVID):
        ct = s1 + 0.25 + i * 0.62
        if t < ct:
            continue
        p = ease_out(min((t - ct) / 0.4, 1.0))
        card = ev_card(title, sub)
        sc = 1.12 - 0.12 * p
        card = card.resize((int(card.width * sc), int(card.height * sc)), Image.LANCZOS)
        x = 118 + i * 578 + (430 - card.width) // 2
        y = int(120 - (1 - p) * 46)
        img.paste(card, (x, y), card)
        d = ImageDraw.Draw(img, "RGBA")
    # ---- the biggest-question card lands on line 2 ----
    qt = s2 + 0.15
    if t >= qt:
        p = ease_out(min((t - qt) / 0.45, 1.0))
        qw, qh = int(1150 * (0.7 + 0.3 * p)), int(260 * (0.7 + 0.3 * p))
        qx, qy = W // 2 - qw // 2, 396 + int((1 - p) * -30)
        d.rounded_rectangle([qx, qy, qx + qw, qy + qh], radius=18,
                            fill=(20, 22, 36, 255), outline=GOLD + (255,), width=3)
        if p > 0.55:
            ctext(d, W // 2, qy + 44, "THE BIGGEST QUESTION", F(64), GOLD, 2)
            ctext(d, W // 2, qy + 148, "WHO WROTE THE LAST PAGE?", FB(44), WHITE, 1)
    # ---- stitched seam splits the frame on line 3 ----
    seam_t = s3 + 0.25
    if t >= seam_t:
        sp = ease_inout(min((t - seam_t) / 0.8, 1.0))
        sx = W // 2
        top_y = 380
        bot_y = int(380 + 450 * sp)
        # stitched seam: dashed gold line + stitch ticks
        yy = top_y
        while yy < bot_y:
            d.line([sx, yy, sx, min(yy + 26, bot_y)], fill=GOLD + (230,), width=4)
            yy += 44
        for yy2 in range(top_y + 10, bot_y - 6, 44):
            d.line([sx - 13, yy2, sx + 13, yy2 + 12], fill=(240, 240, 240, 200), width=3)
        # the two halves of the question card drift apart along the seam
        drift = int(26 * sp)
        d.line([sx - drift, 396, sx - drift, 656], fill=(0, 0, 0, 90), width=2)
        d.line([sx + drift, 396, sx + drift, 656], fill=(0, 0, 0, 90), width=2)
        # stamp across the seam
        if sp > 0.45:
            sw2, sh2 = 520, 92
            bx, by = W // 2 - sw2 // 2, 676
            d.rounded_rectangle([bx, by, bx + sw2, by + sh2], radius=10,
                                fill=(16, 18, 30, 245), outline=RED + (255,), width=3)
            ctext(d, W // 2, by + 24, "ANSWERED IN PART 2", F(40), RED, 1)
    # ---- compressed-answer card peeks in beneath (late line 3) ----
    peek_t = s3 + 1.15
    if t >= peek_t:
        p = ease_out(min((t - peek_t) / 0.5, 1.0))
        cw2, ch2 = 900, 116
        bx = W // 2 - cw2 // 2
        by = int(1030 - 230 * p)   # rises into view and settles at y=800
        by = max(by, 800)
        d.rounded_rectangle([bx, by, bx + cw2, by + ch2], radius=14,
                            fill=(30, 34, 52, 255), outline=(120, 128, 155, 255), width=2)
        if p > 0.5:
            ctext(d, W // 2, by + 12, "WHAT WE CAN SAY TODAY", FB(25), (170, 178, 198), 1)
            ctext(d, W // 2, by + 54, "THE INK IS FROM 1857 — THE HAND IS NOT THE RAJA'S",
                  FB(27), GOLD, 1)
    return img

def tighten(tag):
    """House TP discipline: if the master measures above -1.5 dBTP, trim the
    audio by the excess and re-limit (the s52 'TP-tightening pass')."""
    master = os.path.join(HERE, f"{tag}.mp4")
    q = pc.qc(master, tag)
    if q["tp"] > -1.5:
        gain = -1.55 - q["tp"]
        tmp = os.path.join(HERE, f"{tag}_tp.mp4")
        pc.run(f"ffmpeg -y -loglevel error -i {master} -af volume={gain:.2f}dB,"
               f"alimiter=limit=0.80:level=false -c:v copy -c:a aac -b:a 160k "
               f"-movflags +faststart {tmp}")
        os.replace(tmp, master)
        review = os.path.join(HERE, f"{tag}_review.mp4")
        pc.run(f"ffmpeg -y -loglevel error -i {master} -c:v libx264 -profile:v main -crf 26 "
               f"-preset veryfast -pix_fmt yuv420p -c:a aac -b:a 128k -movflags +faststart {review}")
        q = pc.qc(master, tag)
        print(f"{tag} TP-tightened by {gain:.2f} dB -> LUFS={q['lufs']:.2f} TP={q['tp']:.2f}")
    return q

def main():
    global STARTS, VO_END
    vo = synth_vo(LINES, TAG)
    STARTS, VO_END = _compute(vo["durs"])
    starts = STARTS
    total = VO_END + 0.95
    caps = Caps()
    for s, dur, (txt, hot) in zip(starts, vo["durs"], CAPS):
        caps.add(s, s + dur + 0.25, txt, hot)
    sfx = [("click", starts[0] + 0.25 + i * 0.62 + 0.3, 0.6) for i in range(3)]
    sfx += [("hit", starts[1] + 0.15, 1.0), ("whoosh", starts[2] + 0.25, 0.6),
            ("hit", starts[2] + 0.65, 0.85), ("whoosh", starts[2] + 1.15, 0.5)]
    audio = build_track(total, vo["arrays"], starts, seed=61, sfx=sfx)

    def full(t):
        img = draw(t)
        caps.draw(img, t)
        return img

    finish(TAG, total, full, audio)
    q = tighten(TAG)
    print(TAG, "starts", [round(s, 2) for s in starts], "total", round(total, 2), "QC", q)

if __name__ == "__main__":
    main()
