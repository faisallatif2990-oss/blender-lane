# -*- coding: utf-8 -*-
"""Skill #87 — The living exhibit.
Route: plain route — real-footage edit (the person is the exhibit),
CPU. Fresh original showcase: a voter-roll page highlights one name
and stamps it "DEAD"; the page then slides aside and the exhibit is
produced — real archive footage of a man walking toward the camera,
alive, growing in frame, with a side-box callout beside the footage
("DECLARED DEAD — WALKING, ALIVE", leader line to the frame). The
footage is a real 1901 Edison street film (public domain; see
assets/CREDIT.txt) — a real person on camera, never a staged
substitute. English on-screen text, locked Hindi VO (tts speed 95,
natural speed, pre-generated in this bundle), clean small captions
with gold hot-words, -14 LUFS master.
Lane needs: python3 + Pillow + numpy, ffmpeg. No network, no tts.
"""
import os, sys, math, json, subprocess
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "house"))
from PIL import Image, ImageDraw, ImageFilter, ImageChops
import numpy as np
import proto_common as pc
from proto_common import (W, H, F, tw, ctext, ease_out, ease_inout, GOLD,
                          WHITE, Caps, synth_vo, layout, build_track,
                          finish, solid, vignette_l)
from lab_common import FB, FS, FSB, FM, FMB

pc.LAB = HERE
TAG = "s87"
RED = (198, 44, 32)
GREEN = (64, 178, 110)
PAPER = (238, 231, 214)
INK = (40, 36, 30)
FAUX = (120, 110, 90)
ASSET = os.path.join(HERE, "assets", "walk_s87.mp4")

LINES = [
    # EN: In the government list, this man is dead.
    "सरकारी सूची में यह आदमी मरा हुआ है।",
    # EN: But look — the same man, walking toward the camera.
    "पर देखिए — वही आदमी, कैमरे की तरफ़ चलता हुआ।",
    # EN: Paper can lie — a standing man cannot.
    "काग़ज़ झूठ बोल सकता है — खड़ा इंसान नहीं।",
]
CAPS = [
    ("The official list says this man is DEAD", "DEAD"),
    ("The SAME man — walking toward the camera", "SAME"),
    ("Paper can LIE — a standing man cannot", "LIE"),
]
ROWS = ["MUNSHI LAL — No. 1102", "GANGA RAM — No. 1119", "SITA DEVI — No. 1131",
        "RAM SARAN S/O BUDDHU — No. 1147", "KALLU — No. 1158", "BHOLA NATH — No. 1170"]
TARGET = 3  # index of the highlighted row

# footage window (opens at line 2)
FX, FY, FW, FH = 740, 120, 1100, 830

class Grabber:
    """Sequential raw-frame reader over the bundled footage, looping the
    6 s asset; frame(i) returns the i-th frame at the window size."""
    def __init__(self, path, w, h):
        self.path, self.w, self.h = path, w, h
        self.n = w * h * 3
        self._spawn()
        self.idx = -1; self.cur = None
    def _spawn(self):
        cmd = (f"ffmpeg -v error -i {self.path} -vf fps=24,scale={self.w}:{self.h}:"
               f"force_original_aspect_ratio=increase,crop={self.w}:{self.h} "
               f"-f rawvideo -pix_fmt rgb24 -")
        self.pr = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        self.base = getattr(self, "idx", -1)
    def frame(self, i):
        while self.idx < i:
            buf = self.pr.stdout.read(self.n)
            if len(buf) < self.n:  # asset ended — loop it
                self.pr.stdout.close(); self.pr.terminate()
                self._spawn()
                self.idx = self.base
                buf = self.pr.stdout.read(self.n)
                if len(buf) < self.n:
                    break
            self.cur = Image.frombytes("RGB", (self.w, self.h), buf)
            self.idx += 1
        return self.cur

GRAB = Grabber(ASSET, FW, FH)

def backdrop():
    img = solid((12, 14, 22))
    glow = Image.new("RGB", (W, H), (0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse([140, 30, 1780, 1010], fill=(26, 29, 46))
    glow = glow.filter(ImageFilter.GaussianBlur(150))
    img = ImageChops.add(img, glow)
    return vignette_l(img)

BACK = backdrop()

def stamp_img():
    w, h = 430, 150
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([8, 8, w - 8, h - 8], radius=10, outline=RED + (255,), width=9)
    d.rounded_rectangle([24, 24, w - 24, h - 24], radius=6, outline=RED + (255,), width=3)
    ctext(d, w // 2, h // 2 - 42, "DEAD", F(84), RED + (255,), 1)
    return img.rotate(-11, resample=Image.BICUBIC, expand=True)

STAMP = stamp_img()

def _compute(durs):
    starts, vo_end = layout(durs, gap=0.30)
    return starts, vo_end

try:
    _durs0 = json.load(open(os.path.join(HERE, f"{TAG}_vo.json")))["durs"]
except Exception:
    _durs0 = [2.8, 3.4, 3.2]
STARTS, VO_END = _compute(_durs0)

def roll_page(x, y, w, h, t, s1):
    """The voter-roll page drawn at (x, y, w, h); returns the page image."""
    img = Image.new("RGB", (w, h), PAPER)
    d = ImageDraw.Draw(img, "RGBA")
    d.rectangle([0, 0, w - 1, h - 1], outline=(168, 156, 124, 255), width=4)
    sc = w / 1000.0
    ctext(d, w // 2, int(30 * sc), "VOTER ROLL — WARD 12", FSB(int(40 * sc)), INK, 0)
    ctext(d, w // 2, int(88 * sc), "SUPPLEMENTARY LIST — 1962", FM(int(25 * sc)), FAUX, 0)
    d.line([int(60 * sc), int(140 * sc), w - int(60 * sc), int(140 * sc)], fill=INK + (255,), width=3)
    row_h = int(96 * sc)
    y0 = int(176 * sc)
    for i, name in enumerate(ROWS):
        ry = y0 + i * row_h
        if i == TARGET:
            hp = min(max((t - (s1 + 0.65)) / 0.5, 0.0), 1.0)
            if hp > 0:
                d.rectangle([int(38 * sc), ry - int(10 * sc),
                             int(38 * sc) + int((w - int(76 * sc)) * hp), ry + int(58 * sc)],
                            fill=(255, 205, 40, 130))
        d.text((int(58 * sc), ry), name, font=FM(int(31 * sc)), fill=INK + (255,))
        d.line([int(58 * sc), ry + int(66 * sc), w - int(58 * sc), ry + int(66 * sc)],
               fill=(168, 156, 124, 160), width=1)
    return img

def draw(t):
    s1, s2, s3 = STARTS
    img = BACK.copy()
    d = ImageDraw.Draw(img, "RGBA")
    # ---- page position: centred for line 1, slides left at line 2 ----
    mv = ease_inout(min(max((t - s2) / 0.8, 0.0), 1.0))
    px = int(460 + (80 - 460) * mv)
    py = int(120 + (120 - 120) * mv)
    pw = int(1000 + (620 - 1000) * mv)
    ph = int(840 + (640 - 840) * mv)
    page = roll_page(0, 0, 1000, 840, t, s1).resize((pw, ph), Image.LANCZOS)
    img.paste(page, (px, py))
    d = ImageDraw.Draw(img, "RGBA")
    # ---- the DEAD stamp (line 1, on the paper) ----
    stamp_t = s1 + 1.55
    if t >= stamp_t:
        st = t - stamp_t
        sc = 1.5 - 0.5 * ease_out(min(st / 0.16, 1.0))
        simg = STAMP.resize((int(STAMP.width * sc * pw / 1000), int(STAMP.height * sc * pw / 1000)),
                            Image.LANCZOS)
        shake = int(6 * math.exp(-st * 10)) if st < 0.4 else 0
        sx = px + int(pw * 0.52) + shake
        sy = py + int(ph * (176 + TARGET * 96 - 26) / 840)
        img.paste(simg, (sx, sy), simg)
        d = ImageDraw.Draw(img, "RGBA")
    # ---- the exhibit: real footage (lines 2-3) ----
    if t >= s2:
        fi = int((t - s2) * 24)
        fr = GRAB.frame(fi)
        if fr is not None:
            img.paste(fr, (FX, FY))
            d = ImageDraw.Draw(img, "RGBA")
        d.rectangle([FX, FY, FX + FW, FY + FH], outline=(210, 200, 170, 255), width=4)
        # on-screen credit chip, bottom-left inside the window
        ctxt = "THE EXHIBIT: ARCHIVE FOOTAGE (PUBLIC DOMAIN)"
        cw, _bb = tw(d, ctxt, FM(23), 0)
        d.rounded_rectangle([FX + 18, FY + FH - 58, FX + 18 + cw + 28, FY + FH - 14],
                            radius=8, fill=(0, 0, 0, 180))
        d.text((FX + 32, FY + FH - 50), ctxt, font=FM(23), fill=WHITE + (235,))
    # ---- side-box callout under the page, leader line to the footage ----
    if t >= s3 + 0.15:
        bx, by, bw, bh = 80, 796, 620, 154
        d.rounded_rectangle([bx, by, bx + bw, by + bh], radius=12, fill=(10, 12, 18, 235),
                            outline=GREEN + (255,), width=3)
        d.text((bx + 28, by + 22), "DECLARED DEAD —", font=FB(36), fill=WHITE + (255,))
        d.text((bx + 28, by + 76), "WALKING, ALIVE", font=FB(36), fill=GREEN + (255,))
        d.line([bx + bw, by + bh // 2, FX - 14, FY + FH // 2], fill=GREEN + (230,), width=3)
        d.ellipse([FX - 22, FY + FH // 2 - 8, FX - 6, FY + FH // 2 + 8], fill=GREEN + (255,))
    return img

def tighten(tag):
    """House TP discipline: if the master measures above -1.5 dBTP, trim the
    audio by the excess and re-limit (the s52 'TP-tightening pass')."""
    master = os.path.join(HERE, f"{tag}.mp4")
    q = pc.qc(master, tag)
    if q["tp"] > -1.5:
        gain = -1.55 - q["tp"]
        tmp = os.path.join(HERE, f"{tag}_tp.mp4")
        pc.run(f"ffmpeg -y -loglevel error -i {master} -af volume={gain:.2f}dB,"
               f"alimiter=limit=0.80:level=false -c:v copy -c:a aac -b:a 160k "
               f"-movflags +faststart {tmp}")
        os.replace(tmp, master)
        review = os.path.join(HERE, f"{tag}_review.mp4")
        pc.run(f"ffmpeg -y -loglevel error -i {master} -c:v libx264 -profile:v main -crf 26 "
               f"-preset veryfast -pix_fmt yuv420p -c:a aac -b:a 128k -movflags +faststart {review}")
        q = pc.qc(master, tag)
        print(f"{tag} TP-tightened by {gain:.2f} dB -> LUFS={q['lufs']:.2f} TP={q['tp']:.2f}")
    return q

def main():
    global STARTS, VO_END
    vo = synth_vo(LINES, TAG)
    STARTS, VO_END = _compute(vo["durs"])
    starts = STARTS
    total = VO_END + 0.95
    caps = Caps()
    for s, dur, (txt, hot) in zip(starts, vo["durs"], CAPS):
        caps.add(s, s + dur + 0.25, txt, hot)
    sfx = [("hit", starts[0] + 1.55, 0.95), ("whoosh", starts[1], 0.55),
           ("hit", starts[2] + 0.15, 0.7)]
    audio = build_track(total, vo["arrays"], starts, seed=87,
                        music_freqs=(55.0, 82.4, 110.0), sfx=sfx)

    def full(t):
        img = draw(t)
        caps.draw(img, t)
        return img

    finish(TAG, total, full, audio)
    q = tighten(TAG)
    print(TAG, "starts", [round(s, 2) for s in starts], "total", round(total, 2), "QC", q)

if __name__ == "__main__":
    main()
