# -*- coding: utf-8 -*-
"""Skill #65 — Trailer cold open (montage the film's own best material).
Route: plain route — footage/document edit, CPU. Fresh original showcase:
the cold open is cut from the film's OWN later material — a document
highlight, a map dive, a sealed-file stamp, a diary date, the map again
closer, a one-line verdict card — six flashes at trailer pace, then a
freeze on black and the thesis line crashes in as the title. Hard cuts
only, no fades; white flash frames on the last three cuts; a riser into
the freeze. English on-screen text, locked Hindi VO (tts speed 95,
natural speed, pre-generated in this bundle), clean small captions with
gold hot-words, -14 LUFS master.
Lane needs: python3 + Pillow + numpy, ffmpeg. No network, no tts.
"""
import os, sys, math
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "house"))
from PIL import Image, ImageDraw, ImageFilter, ImageChops
import numpy as np
import proto_common as pc
from proto_common import (W, H, F, tw, ctext, ease_out, ease_inout, GOLD,
                          WHITE, Caps, synth_vo, build_track, solid,
                          vignette_l)
from lab_common import FB, FS, FSB, FM, FMB

pc.LAB = HERE
TAG = "s65"
VERM = (198, 44, 32)
PAPER = (238, 230, 208)
INK = (38, 34, 30)
FAUX = (150, 140, 116)

LINES = [
    # EN: In this film — a document, a map, and a seal.
    "इस फ़िल्म में — एक दस्तावेज़, एक नक्शा, और एक मुहर।",
    # EN: And at the end, the question from which it all begins.
    "और आख़िर में, वो सवाल जिससे सब शुरू होता है।",
]
CAPS = [
    ("Ahead in this film — a DOCUMENT, a map, a seal", "DOCUMENT"),
    ("And at the end — the QUESTION that starts it all", "QUESTION"),
]
TOTAL = 10.30
VO_STARTS = [0.25, 5.15]
CUTS = [1.45, 2.60, 3.45, 4.05, 4.50, 4.80]
FLASH_CUTS = [3.45, 4.05, 4.50]
FORT = (1250, 420)

def desk():
    img = solid((14, 13, 12))
    glow = Image.new("RGB", (W, H), (0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse([W // 2 - 780, 40, W // 2 + 780, 1020], fill=(52, 46, 34))
    glow = glow.filter(ImageFilter.GaussianBlur(170))
    return vignette_l(ImageChops.add(img, glow))

DESK = desk()

def faux_lines(d, x, y, widths, gap=34, col=(168, 158, 132, 255), hgt=10):
    for wd in widths:
        d.rectangle([x, y, x + wd, y + hgt], fill=col)
        y += gap

# ------------------------------------------------------------ beat 1: order page
def beat_doc(t):
    img = DESK.copy()
    d = ImageDraw.Draw(img, "RGBA")
    px, py, pw, ph = 340, 150, 1240, 780
    d.rectangle([px + 14, py + 18, px + pw + 14, py + ph + 18], fill=(0, 0, 0, 110))
    d.rectangle([px, py, px + pw, py + ph], fill=PAPER + (255,))
    d.rectangle([px + 18, py + 18, px + pw - 18, py + ph - 18],
                outline=(150, 138, 108, 255), width=2)
    ctext(d, px + pw // 2, py + 52, "FORT ORDERS — BY COMMAND", FMB(30), FAUX, 1)
    d.line([px + 70, py + 108, px + pw - 70, py + 108], fill=INK + (255,), width=2)
    faux_lines(d, px + 90, py + 150, [1050, 980, 1060])
    line = "THE GATES CLOSE AT MIDNIGHT"
    ly = py + 300
    lw, bb = tw(d, line, FSB(46), 1)
    lx = px + (pw - lw) // 2 - bb[0]
    hp = min(max((t - 0.35) / 0.95, 0.0), 1.0)
    if hp > 0:
        d.rectangle([lx - 10, ly - 8, lx - 10 + (lw + 20) * hp, ly + 62],
                    fill=(255, 205, 60, 130))
    d.text((lx, ly), line, font=FSB(46), fill=INK + (255,))
    faux_lines(d, px + 90, py + 420, [1020, 1080, 940])
    d.text((px + 90, py + 560), "— by order of the Commandant, at sunset.",
           font=FS(30), fill=(92, 84, 70, 255))
    # the fort seal, drawn on the paper
    cx, cy = px + pw - 170, py + ph - 150
    d.ellipse([cx - 74, cy - 74, cx + 74, cy + 74], outline=VERM + (230,), width=5)
    d.ellipse([cx - 56, cy - 56, cx + 56, cy + 56], outline=VERM + (200,), width=2)
    ctext(d, cx, cy - 34, "FORT", F(30), VERM, 1)
    ctext(d, cx, cy + 2, "HQ", F(30), VERM, 1)
    return img

# ------------------------------------------------------------ beats 2/5: the map
def map_base(route_p, pulse_r):
    img = Image.new("RGB", (W, H), (226, 208, 168))
    d = ImageDraw.Draw(img, "RGBA")
    rng = np.random.default_rng(65)
    for _ in range(2600):
        x, y = int(rng.integers(0, W)), int(rng.integers(0, H))
        d.point((x, y), fill=(120, 100, 66, 60))
    # river sweeping down the left
    pts = [(120, -20), (330, 240), (300, 520), (470, 800), (430, 1100)]
    d.line(pts, fill=(96, 128, 150, 255), width=46, joint="curve")
    d.line(pts, fill=(140, 172, 196, 255), width=26, joint="curve")
    # hills as classic hachure arcs — parchment-map furniture
    for cx, cy in [(1400, 330), (1640, 580), (1150, 660), (720, 280), (1560, 180)]:
        for r in (26, 52, 80, 108):
            d.arc([cx - r, cy - int(r * 0.62), cx + r, cy + int(r * 0.62)],
                  start=185, end=355, fill=(148, 118, 76, 200), width=5)
    # tree glyphs scattered on the plain
    for tx, ty in [(520, 420), (600, 470), (880, 300), (980, 760), (760, 900),
                   (1480, 780), (1720, 380), (420, 640), (1080, 180), (880, 520)]:
        d.polygon([(tx - 13, ty), (tx + 13, ty), (tx, ty - 30)], fill=(96, 116, 74, 255))
        d.line([tx, ty, tx, ty + 9], fill=(110, 88, 58, 255), width=4)
    # compass rose, top-left of the plate
    d.polygon([(150, 66), (162, 108), (150, 100), (138, 108)], fill=INK + (255,))
    ctext(d, 150, 118, "N", F(26), INK, 1)
    # the road: dashed, drawing itself to the fort
    road = [(250, 880), (560, 760), (820, 640), (1050, 520), FORT]
    full = []
    for a, b in zip(road, road[1:]):
        for k in range(25):
            full.append((a[0] + (b[0] - a[0]) * k / 25, a[1] + (b[1] - a[1]) * k / 25))
    full.append(FORT)
    n = int(len(full) * route_p)
    for i in range(0, n - 1, 2):
        d.line([full[i], full[i + 1]], fill=(150, 52, 36, 255), width=7)
    # the fort: walls + tower
    fx, fy = FORT
    d.polygon([(fx - 66, fy + 26), (fx - 40, fy - 30), (fx + 6, fy - 52),
               (fx + 58, fy - 26), (fx + 66, fy + 26)], fill=(120, 96, 70, 255),
              outline=INK + (255,))
    d.rectangle([fx - 12, fy - 92, fx + 14, fy - 40], fill=(104, 82, 58, 255),
                outline=INK + (255,))
    d.polygon([(fx - 20, fy - 92), (fx + 22, fy - 92), (fx + 1, fy - 118)],
              fill=VERM + (255,))
    if pulse_r:
        d.ellipse([fx - pulse_r, fy - pulse_r, fx + pulse_r, fy + pulse_r],
                  outline=GOLD + (255,), width=5)
    d.ellipse([fx - 9, fy - 9, fx + 9, fy + 9], fill=GOLD + (255,))
    return img

def zoom_view(base, centre, crop_w):
    ch = int(crop_w * H / W)
    x0 = int(min(max(centre[0] - crop_w // 2, 0), W - crop_w))
    y0 = int(min(max(centre[1] - ch // 2, 0), H - ch))
    view = base.crop((x0, y0, x0 + crop_w, y0 + ch)).resize((W, H), Image.LANCZOS)
    return view, (x0, y0, crop_w / W)

def beat_map(t, closer=False):
    if not closer:
        p = ease_inout(min((t - 1.45) / 1.15, 1.0))
        centre = (960 + 220 * p, 540 - 70 * p)
        crop_w = int(1920 - 500 * p)
        route_p = 0.15 + 0.6 * p
    else:
        p = ease_inout(min((t - 4.05) / 0.45, 1.0))
        centre = (1120 + 40 * p, 500 - 20 * p)
        crop_w = int(1560 - 230 * p)
        route_p = 0.75 + 0.25 * p
    pulse = int(26 + 10 * math.sin(t * 9)) if closer else int(20 + 6 * math.sin(t * 7))
    base = map_base(route_p, pulse)
    view, (x0, y0, sc) = zoom_view(base, centre, crop_w)
    if not closer:
        d = ImageDraw.Draw(view, "RGBA")
        fsx, fsy = int((FORT[0] - x0) / sc), int((FORT[1] - y0) / sc)
        # fort label BESIDE the fort, in its own box, with a leader line
        bx, by, bw = 1300, 108, 520
        d.line([bx, by + 78, fsx + 16, fsy - 10], fill=(30, 26, 20, 230), width=3)
        d.ellipse([fsx + 9, fsy - 17, fsx + 23, fsy - 3], fill=GOLD + (255,))
        d.rounded_rectangle([bx, by, bx + bw, by + 118], radius=12,
                            fill=(250, 244, 226, 245), outline=INK + (255,), width=3)
        d.text((bx + 24, by + 16), "THE HILL FORT", font=F(36), fill=INK + (255,))
        d.text((bx + 24, by + 66), "One road in. One gate.", font=FB(28),
               fill=(92, 84, 70, 255))
    return view

# ------------------------------------------------------------ beat 3: sealed file
def stamp_img(scale, rot):
    sw, sh = 820, 190
    img = Image.new("RGBA", (sw, sh), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([10, 10, sw - 10, sh - 10], radius=14, outline=VERM + (255,), width=12)
    ctext(d, sw // 2, 56, "SEALED FOR 70 YEARS", F(66), VERM, 2)
    img = img.resize((int(sw * scale), int(sh * scale)), Image.LANCZOS)
    return img.rotate(rot, resample=Image.BICUBIC, expand=True)

def beat_file(t):
    img = DESK.copy()
    d = ImageDraw.Draw(img, "RGBA")
    px, py, pw, ph = 410, 220, 1100, 640
    d.rectangle([px + 14, py + 16, px + pw + 14, py + ph + 16], fill=(0, 0, 0, 110))
    d.rectangle([px, py - 44, px + 330, py + 4], fill=(96, 78, 52, 255))
    d.rectangle([px, py, px + pw, py + ph], fill=(110, 90, 60, 255))
    d.rectangle([px + 26, py + 26, px + pw - 26, py + ph - 26],
                outline=(210, 192, 150, 255), width=2)
    ctext(d, px + pw // 2, py + 66, "CASE FILE — THE FORT PAPERS", F(46),
          (246, 238, 218), 1)
    ctext(d, px + pw // 2, py + 140, "STATUS: CLOSED TO ALL READERS", FMB(29),
          (216, 202, 168), 1)
    ctext(d, px + pw // 2, py + 196, "OPENED BY ORDER ONLY · HANDLE WITH CARE", FM(24),
          (188, 172, 138), 1)
    if t >= 2.85:
        st = t - 2.85
        sc = 1.0 + 0.85 * math.exp(-st * 13) * (1 if st < 0.22 else 0.25)
        shake = int(7 * math.exp(-st * 10)) if st < 0.4 else 0
        st_img = stamp_img(sc, -11)
        img.paste(st_img, (px + pw // 2 - st_img.width // 2 + shake, py + 268), st_img)
    return img

# ------------------------------------------------------------ beat 4: diary date
def beat_diary(t):
    img = DESK.copy()
    d = ImageDraw.Draw(img, "RGBA")
    px, py, pw, ph = 460, 190, 1000, 700
    d.rectangle([px + 14, py + 16, px + pw + 14, py + ph + 16], fill=(0, 0, 0, 110))
    d.rectangle([px, py, px + pw, py + ph], fill=PAPER + (255,))
    for yy in range(py + 120, py + ph - 60, 56):
        d.line([px + 60, yy, px + pw - 60, yy], fill=(170, 178, 200, 160), width=2)
    d.line([px + 96, py + 30, px + 96, py + ph - 30], fill=(216, 150, 140, 200), width=2)
    date = "17 AUGUST 1857"
    dy = py + 148
    dw, bb = tw(d, date, FSB(58), 1)
    dx = px + 130 - bb[0]
    hp = min(max((t - 3.55) / 0.4, 0.0), 1.0)
    if hp > 0:
        d.rectangle([dx - 10, dy - 6, dx - 10 + (dw + 20) * hp, dy + 74],
                    fill=(255, 205, 60, 130))
    d.text((dx, dy), date, font=FSB(58), fill=(40, 44, 74, 255))
    # handwriting: wavy script strokes
    rng = np.random.default_rng(4)
    for row, wd in enumerate((760, 700, 780, 560)):
        yy = py + 300 + row * 72
        pts = [(px + 130 + k * 18, yy + int(5 * math.sin(k * 0.7 + row * 2.0)))
               for k in range(wd // 18)]
        d.line(pts, fill=(70, 74, 104, 220), width=3)
    d.text((px + 130, py + ph - 108), "the gates were shut before dark.",
           font=FS(29), fill=(92, 84, 70, 255))
    return img

# ------------------------------------------------------------ beat 6: verdict
def beat_verdict(t):
    img = solid((8, 8, 10))
    d = ImageDraw.Draw(img, "RGBA")
    lt = t - 4.50
    ctext(d, W // 2, 372, "AND THE VERDICT —", FB(31), (168, 172, 184), 1)
    sc = 1.0 + 0.35 * math.exp(-lt * 16) * (1 if lt < 0.2 else 0.2)
    txt = "NOT AN ACCIDENT"
    fnt = F(int(104 * sc))
    wpx, bb = tw(d, txt, fnt, 2)
    shake = int(5 * math.exp(-lt * 11)) if lt < 0.35 else 0
    d.text((W // 2 - wpx // 2 - bb[0] + shake, 448 - bb[1]), txt, font=fnt,
           fill=(255, 255, 255, 255))
    uw = int(wpx * min(lt / 0.25, 1.0))
    d.rectangle([W // 2 - uw // 2, 592, W // 2 + uw // 2, 604], fill=VERM + (255,))
    return img

# ------------------------------------------------------------ freeze: the thesis
THESIS = "THE FORT DID NOT FALL IN A DAY."
def thesis_layer(scale, spacing):
    scratch = ImageDraw.Draw(Image.new("RGB", (10, 10)))
    fnt = F(max(int(66 * scale), 8))
    widths = [tw(scratch, ch, fnt, 0)[0] for ch in THESIS]
    tot = sum(widths) + spacing * (len(THESIS) - 1)
    img = Image.new("RGBA", (tot + 8, 120), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    x = 4
    for ch, wd in zip(THESIS, widths):
        d.text((x, 18), ch, font=fnt, fill=(255, 255, 255, 255))
        x += wd + spacing
    return img

def beat_freeze(t):
    img = solid((5, 5, 7))
    lt = t - 5.30
    if lt >= 0:
        p = min(lt / 0.30, 1.0)
        scale = 2.1 - 1.1 * ease_out(p)
        spacing = int(30 * (1 - ease_out(p))) + 2
        layer = thesis_layer(scale, spacing)
        # a slow light sweeps through the letters during the hold
        mask = layer.split()[3]
        sweep_x = -500 + (max(t - 5.8, 0.0) / 4.4) * (layer.width + 1000)
        grad = Image.new("L", layer.size, 0)
        gd = ImageDraw.Draw(grad)
        for k in range(260):
            a = int(190 * math.exp(-((k - 130) ** 2) / (2 * 52 ** 2)))
            gd.line([sweep_x + k, 0, sweep_x + k, layer.height], fill=a)
        shine = Image.new("RGBA", layer.size, (255, 226, 160, 0))
        shine.putalpha(ImageChops.multiply(mask, grad))
        out = layer.copy()
        out.alpha_composite(shine)
        img.paste(out, (W // 2 - layer.width // 2, 452), out)
        d = ImageDraw.Draw(img, "RGBA")
        if t >= 6.40:
            sub = "A  H I S T O R Y  V A U L T  I N V E S T I G A T I O N"
            a = min(int((t - 6.40) / 0.8 * 255), 255)
            ctext(d, W // 2, 616, sub, FM(25), (212, 182, 110, a), 1)
    return img

def tighten(tag):
    """House TP discipline: if the master measures above -1.5 dBTP, trim the
    audio by the excess and re-limit (the s52 'TP-tightening pass')."""
    master = os.path.join(HERE, f"{tag}.mp4")
    q = pc.qc(master, tag)
    if q["tp"] > -1.5:
        gain = -1.55 - q["tp"]
        tmp = os.path.join(HERE, f"{tag}_tp.mp4")
        pc.run(f"ffmpeg -y -loglevel error -i {master} -af volume={gain:.2f}dB,"
               f"alimiter=limit=0.80:level=false -c:v copy -c:a aac -b:a 160k "
               f"-movflags +faststart {tmp}")
        os.replace(tmp, master)
        review = os.path.join(HERE, f"{tag}_review.mp4")
        pc.run(f"ffmpeg -y -loglevel error -i {master} -c:v libx264 -profile:v main "
               f"-crf 26 -preset veryfast -pix_fmt yuv420p -c:a aac -b:a 128k "
               f"-movflags +faststart {review}")
        q = pc.qc(master, tag)
        print(f"{tag} TP-tightened by {gain:.2f} dB -> LUFS={q['lufs']:.2f} TP={q['tp']:.2f}")
    return q

# ---------------------------------------------------------------- build
def main():
    vo = synth_vo(LINES, TAG)
    caps = Caps()
    for s, dur, (txt, hot) in zip(VO_STARTS, vo["durs"], CAPS):
        caps.add(s, s + dur + 0.25, txt, hot)
    sfx = [("whoosh", 1.45, 0.55), ("whoosh", 2.60, 0.65), ("whoosh", 3.45, 0.75),
           ("whoosh", 4.05, 0.85), ("hit", 2.85, 1.0), ("hit", 4.52, 1.0),
           ("riser", 4.78, 1.0), ("hit", 5.30, 1.0)]
    audio = build_track(TOTAL, vo["arrays"], VO_STARTS, seed=29, sfx=sfx,
                        music_gain=0.32)

    def draw(t):
        if t < 1.45:
            img = beat_doc(t)
        elif t < 2.60:
            img = beat_map(t)
        elif t < 3.45:
            img = beat_file(t)
        elif t < 4.05:
            img = beat_diary(t)
        elif t < 4.50:
            img = beat_map(t, closer=True)
        elif t < 4.80:
            img = beat_verdict(t)
        else:
            img = beat_freeze(t)
        for fc in FLASH_CUTS:
            if fc <= t < fc + 2 / 24:
                a = 175 if t < fc + 1 / 24 else 80
                img.paste(Image.new("RGB", (W, H), (255, 255, 255)),
                          (0, 0), Image.new("L", (W, H), a))
        return img

    def full(t):
        img = draw(t)
        caps.draw(img, t)
        return img

    pc.finish(TAG, TOTAL, full, audio)
    q = tighten(TAG)
    print(TAG, "vo durs", vo["durs"], "total", TOTAL, "QC", q)

if __name__ == "__main__":
    main()
