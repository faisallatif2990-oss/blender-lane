# -*- coding: utf-8 -*-
"""Skill #85 — The withheld exhibit.
Route: plain route — document-highlight (fragment + absence inventory),
CPU. Fresh original showcase: an inquiry transcript sheet rises
full-front — twelve minutes of questioning, ONE line released, lit and
highlighted ("THE GATE WAS ORDERED SHUT AT 9:40"); below it, a grey
void where the rest should be. Side boxes name the missing parts one
by one — "THE OTHER 11 MINUTES — WITHHELD", "THE ORDER SHEET —
WITHHELD", "THE GUARD'S STATEMENT — WITHHELD" — until the absence
itself fills the frame and becomes the finding. English on-screen
text, locked Hindi VO (tts speed 95, natural speed, pre-generated in
this bundle), clean small captions with gold hot-words, -14 LUFS
master.
Lane needs: python3 + Pillow + numpy, ffmpeg. No network, no tts.
"""
import os, sys, math, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "house"))
from PIL import Image, ImageDraw, ImageFilter, ImageChops
import numpy as np
import proto_common as pc
from proto_common import (W, H, F, tw, ctext, ease_out, ease_inout, GOLD,
                          WHITE, Caps, synth_vo, layout, build_track,
                          finish, solid, vignette_l)
from lab_common import FB, FS, FSB, FM, FMB

pc.LAB = HERE
TAG = "s85"
RED = (205, 52, 40)
PAPER = (238, 231, 214)
INK = (40, 36, 30)
FAUX = (120, 110, 90)
VOID = (96, 98, 106)
SX, SY, SW, SH = 280, 140, 900, 800
MISSING = [("THE OTHER 11 MINUTES", "— WITHHELD"),
           ("THE ORDER SHEET", "— WITHHELD"),
           ("THE GUARD'S STATEMENT", "— WITHHELD")]

LINES = [
    # EN: Twelve minutes of questioning — only one line released.
    "बारह मिनट की पूछताछ — जारी हुई सिर्फ़ एक पंक्ति।",
    # EN: Everything else was held back — the order sheet too, the guard's statement too.
    "बाकी सब रोका गया — आदेश-पत्र भी, पहरेदार का बयान भी।",
    # EN: What was hidden — that is the real news of this inquiry.
    "जो छिपाया गया — वही इस जाँच की असली ख़बर है।",
]
CAPS = [
    ("TWELVE minutes of questions — one line released", "TWELVE"),
    ("The rest WITHHELD — the order sheet, the statement", "WITHHELD"),
    ("What was HIDDEN is the real finding", "HIDDEN"),
]

def backdrop():
    img = solid((13, 15, 24))
    glow = Image.new("RGB", (W, H), (0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse([180, 40, 1740, 1020], fill=(30, 33, 54))
    glow = glow.filter(ImageFilter.GaussianBlur(150))
    img = ImageChops.add(img, glow)
    return vignette_l(img)

BACK = backdrop()

def _compute(durs):
    starts, vo_end = layout(durs, gap=0.30)
    return starts, vo_end

try:
    _durs0 = json.load(open(os.path.join(HERE, f"{TAG}_vo.json")))["durs"]
except Exception:
    _durs0 = [3.0, 3.6, 2.8]
STARTS, VO_END = _compute(_durs0)

def sheet(t):
    """The transcript sheet as its own image (drawn at final position)."""
    s1, s2, s3 = STARTS
    img = Image.new("RGBA", (SW, SH), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, SW, SH], fill=PAPER + (255,), outline=(168, 156, 124, 255), width=4)
    ctext(d, SW // 2, 34, "INQUIRY TRANSCRIPT", FSB(38), INK, 0)
    ctext(d, SW // 2, 92, "SESSION 4 — RUNNING TIME 12:00", FM(25), FAUX, 0)
    d.text((SW - 268, 40), "RELEASED: 1 / 214", font=FMB(21), fill=RED + (255,))
    d.line([56, 148, SW - 56, 148], fill=INK + (255,), width=3)
    # a few faint ruled lines above the released line
    for i, fw in enumerate((0.92, 0.85, 0.9)):
        y = 178 + i * 40
        d.rectangle([64, y, 64 + int((SW - 128) * fw), y + 9], fill=(178, 168, 146, 255))
    # the ONE released line, highlighted; the highlight sweeps during line 1
    ly = 316
    sweep = ease_out(min(max((t - 0.95) / 1.1, 0.0), 1.0))
    d.rectangle([48, ly - 10, 48 + int((SW - 96) * sweep), ly + 58],
                fill=(255, 205, 40, 130))
    d.text((64, ly + 4), "09:40 — THE GATE WAS ORDERED SHUT.", font=FSB(34), fill=INK + (255,))
    # the grey void below: everything that should follow, withheld
    vy = 420
    d.rectangle([48, vy, SW - 48, SH - 48], fill=VOID + (255,))
    for k in range(0, SW - 96, 46):  # diagonal hatch
        d.line([48 + k, SH - 48, 48 + k + 180, vy], fill=(84, 86, 94, 255), width=7)
    ctext(d, SW // 2, vy + 120, "11 MINUTES 24 SECONDS", F(44), (196, 198, 206), 1)
    ctext(d, SW // 2, vy + 190, "— WITHHELD —", FB(34), (170, 172, 180), 1)
    # red frame closes around the void on line 3
    if t > s3 + 0.25:
        p = ease_out(min((t - s3 - 0.25) / 0.5, 1.0))
        inset = int(10 * p)
        d.rectangle([48 - inset, vy - inset, SW - 48 + inset, SH - 48 + inset],
                    outline=RED + (255,), width=2 + int(4 * p))
    return img

def draw(t):
    s1, s2, s3 = STARTS
    img = BACK.copy()
    d = ImageDraw.Draw(img, "RGBA")
    # sheet rises full-front
    rp = ease_out(min(max((t - 0.20) / 0.7, 0.0), 1.0))
    sy = int(SY + (1 - rp) * 560)
    sh = sheet(t)
    img.paste(sh, (SX, sy), sh)
    d = ImageDraw.Draw(img, "RGBA")
    # ---- side boxes name the missing parts (line 2) ----
    void_mid_y = sy + 640
    for i, (title, sub) in enumerate(MISSING):
        bt = s2 + 0.30 + i * 0.80
        if t < bt:
            continue
        p = ease_out(min((t - bt) / 0.4, 1.0))
        bw, bh = 520, 118
        bx = int(1300 + (1 - p) * 420)
        by = 250 + i * 190
        anchor = (SX + SW, min(by + bh // 2, void_mid_y + i * 40))
        d.line([anchor[0], anchor[1], bx, by + bh // 2], fill=(235, 232, 220, 220), width=3)
        d.ellipse([anchor[0] - 7, anchor[1] - 7, anchor[0] + 7, anchor[1] + 7], fill=RED + (255,))
        d.rounded_rectangle([bx, by, bx + bw, by + bh], radius=12,
                            fill=(12, 14, 22, 235), outline=RED + (255,), width=2)
        if p > 0.5:
            d.text((bx + 26, by + 16), title, font=FB(31), fill=WHITE + (255,))
            d.text((bx + 26, by + 64), sub, font=F(30), fill=RED + (255,))
    # ---- the finding bar lands on line 3 ----
    if t > s3 + 0.55:
        p = ease_out(min((t - s3 - 0.55) / 0.45, 1.0))
        bw = int(760 * p)
        d.rounded_rectangle([W // 2 - bw // 2, 36, W // 2 + bw // 2, 112], radius=12,
                            fill=(16, 18, 30, 245), outline=RED + (255,), width=3)
        if p > 0.65:
            ctext(d, W // 2, 54, "THE GAP IS THE FINDING", F(40), RED, 1)
    return img

def tighten(tag):
    """House TP discipline: if the master measures above -1.5 dBTP, trim the
    audio by the excess and re-limit (the s52 'TP-tightening pass')."""
    master = os.path.join(HERE, f"{tag}.mp4")
    q = pc.qc(master, tag)
    if q["tp"] > -1.5:
        gain = -1.55 - q["tp"]
        tmp = os.path.join(HERE, f"{tag}_tp.mp4")
        pc.run(f"ffmpeg -y -loglevel error -i {master} -af volume={gain:.2f}dB,"
               f"alimiter=limit=0.80:level=false -c:v copy -c:a aac -b:a 160k "
               f"-movflags +faststart {tmp}")
        os.replace(tmp, master)
        review = os.path.join(HERE, f"{tag}_review.mp4")
        pc.run(f"ffmpeg -y -loglevel error -i {master} -c:v libx264 -profile:v main -crf 26 "
               f"-preset veryfast -pix_fmt yuv420p -c:a aac -b:a 128k -movflags +faststart {review}")
        q = pc.qc(master, tag)
        print(f"{tag} TP-tightened by {gain:.2f} dB -> LUFS={q['lufs']:.2f} TP={q['tp']:.2f}")
    return q

def main():
    global STARTS, VO_END
    vo = synth_vo(LINES, TAG)
    STARTS, VO_END = _compute(vo["durs"])
    starts = STARTS
    total = VO_END + 0.95
    caps = Caps()
    for s, dur, (txt, hot) in zip(starts, vo["durs"], CAPS):
        caps.add(s, s + dur + 0.25, txt, hot)
    sfx = [("whoosh", 0.2, 0.55), ("hit", 0.9, 0.7)]
    sfx += [("hit", starts[1] + 0.30 + i * 0.80, 0.8) for i in range(3)]
    sfx += [("hit", starts[2] + 0.55, 0.95)]
    audio = build_track(total, vo["arrays"], starts, seed=97,
                        music_freqs=(55.0, 82.4, 110.0), sfx=sfx)

    def full(t):
        img = draw(t)
        caps.draw(img, t)
        return img

    finish(TAG, total, full, audio)
    q = tighten(TAG)
    print(TAG, "starts", [round(s, 2) for s in starts], "total", round(total, 2), "QC", q)

if __name__ == "__main__":
    main()
