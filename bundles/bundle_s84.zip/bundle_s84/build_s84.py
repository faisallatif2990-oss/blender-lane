# -*- coding: utf-8 -*-
"""Skill #84 — The sponsor changelog.
Route: motionmaxxing — comment->change card choreography, CPU. Built in
the transferable HV form (as ordered, like #74): no sponsor exists, so
the segment is the channel's OWN changelog — audience feedback quoted
as the cause, the changes as the effect, before/after numbers as the
proof — never a fresh pitch. Three viewer-comment cards land; each
flips into a "CHANGED:" card, its number ticking upward as it turns.
English on-screen text, locked Hindi VO (tts speed 95, natural speed,
pre-generated in this bundle), clean small captions with gold
hot-words, -14 LUFS master.
Lane needs: python3 + Pillow + numpy, ffmpeg. No network, no tts.
"""
import os, sys, math, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "house"))
from PIL import Image, ImageDraw, ImageFilter, ImageChops
import numpy as np
import proto_common as pc
from proto_common import (W, H, F, tw, ctext, ease_out, ease_inout, GOLD,
                          WHITE, Caps, synth_vo, layout, build_track,
                          finish, solid, vignette_l)
from lab_common import FB, FS, FSB, FM, FMB, count_up

pc.LAB = HERE
TAG = "s84"
GREEN = (46, 170, 92)
ROWS = [
    ("@viewer_214", "“No subtitles — I watch on mute.”", "V",
     "SUBTITLES: OFF → ON", "VIDEOS WITH SUBTITLES", 100, "%"),
    ("@historyfan_88", "“Your maps are flat.”", "H",
     "MAPS: FLAT → 3D", "MAP SCENES IN 3D", 27, ""),
    ("@student_307", "“Answers come too late.”", "S",
     "ANSWERS: NEXT DAY → SAME DAY", "ANSWERS PINNED SAME DAY", 41, ""),
]
ROW_Y = [296, 512, 728]
CW, CH = 940, 168

LINES = [
    # EN: You said it — we changed it. This is a report, not an advertisement.
    "आपने कहा — हमने बदला। यह रिपोर्ट है, विज्ञापन नहीं।",
    # EN: Subtitles now in every video — maps now three-dimensional.
    "उपशीर्षक अब हर वीडियो में — नक्शे अब त्रि-आयामी।",
    # EN: And answers — now the same day, pinned.
    "और जवाब — अब उसी दिन, पिन किया हुआ।",
]
CAPS = [
    ("You SAID it — we changed it. A report, not an ad", "SAID"),
    ("SUBTITLES on every video — maps in 3D", "SUBTITLES"),
    ("Answers — SAME day now, pinned", "SAME"),
]

def backdrop():
    img = solid((14, 16, 30))
    glow = Image.new("RGB", (W, H), (0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse([W // 2 - 800, 60, W // 2 + 800, 980], fill=(38, 40, 80))
    glow = glow.filter(ImageFilter.GaussianBlur(180))
    img = ImageChops.add(img, glow)
    d = ImageDraw.Draw(img, "RGBA")
    for gx in range(90, W - 60, 60):
        for gy in range(70, H - 60, 60):
            d.ellipse([gx, gy, gx + 3, gy + 3], fill=(150, 150, 210, 24))
    return vignette_l(img)

BACK = backdrop()
_rng = np.random.default_rng(84)
DUST = [(int(_rng.integers(0, W)), int(_rng.integers(0, H)), int(_rng.integers(1, 4)),
         float(_rng.uniform(4, 14))) for _ in range(40)]

def comment_card(handle, text, initial):
    img = Image.new("RGBA", (CW, CH), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([4, 4, CW - 4, CH - 4], radius=14, fill=(24, 27, 40, 255),
                        outline=(62, 67, 88, 255), width=2)
    d.ellipse([28, 44, 108, 124], fill=(52, 58, 78, 255), outline=GOLD + (255,), width=3)
    ctext(d, 68, 62, initial, F(44), GOLD, 0)
    d.text((136, 34), handle, font=FB(29), fill=GOLD + (255,))
    d.text((136, 82), text, font=FB(33), fill=WHITE + (255,))
    ctext(d, CW - 120, 118, "YOU SAID", FM(22), (150, 156, 175), 0)
    return img

def change_card(change, label, num, suffix):
    img = Image.new("RGBA", (CW, CH), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([4, 4, CW - 4, CH - 4], radius=14, fill=(18, 30, 26, 255),
                        outline=GREEN + (255,), width=3)
    d.rounded_rectangle([28, 26, 208, 74], radius=8, fill=GREEN + (255,))
    ctext(d, 118, 34, "CHANGED", FB(30), (10, 16, 12), 0)
    d.text((28, 92), change, font=F(37), fill=WHITE + (255,))
    # number block at the right
    d.line([CW - 250, 24, CW - 250, CH - 24], fill=(70, 90, 80, 255), width=2)
    ctext(d, CW - 128, 30, f"{num}{suffix}", F(64), GOLD, 1)
    ctext(d, CW - 128, 112, label, FM(19), (168, 190, 178), 0)
    return img

def _compute(durs):
    starts, vo_end = layout(durs, gap=0.30)
    return starts, vo_end

try:
    _durs0 = json.load(open(os.path.join(HERE, f"{TAG}_vo.json")))["durs"]
except Exception:
    _durs0 = [3.2, 3.2, 2.6]
STARTS, VO_END = _compute(_durs0)

def flips():
    s1, s2, s3 = STARTS
    dur2 = s3 - s2
    return [s2 + 0.25, s2 + 0.25 + dur2 * 0.52, s3 + 0.35]

def draw(t):
    s1, s2, s3 = STARTS
    img = BACK.copy()
    breathe = 0.5 + 0.5 * math.sin(t * 1.7)
    glow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse([W // 2 - 660, 40, W // 2 + 660, 640], fill=(255, 205, 40, int(8 + 12 * breathe)))
    img = Image.alpha_composite(img.convert("RGBA"), glow).convert("RGB")
    d = ImageDraw.Draw(img, "RGBA")
    for x, y, r, sp in DUST:
        yy = (y + t * sp) % H
        d.ellipse([x - r, yy - r, x + r, yy + r], fill=(255, 214, 130, 32))
    # ---- header slam (line 1) ----
    hp = ease_out(min(t / 0.42, 1.0))
    if hp > 0:
        sc = 1.5 - 0.5 * hp
        fnt = F(int(76 * sc))
        wpx, bb = tw(d, "YOU SAID IT — WE CHANGED IT", fnt, 3)
        d.text((W // 2 - wpx // 2 - bb[0], 66 - bb[1]), "YOU SAID IT — WE CHANGED IT",
               font=fnt, fill=GOLD + (255,), stroke_width=3, stroke_fill=(0, 0, 0, 235))
        if hp > 0.7:
            ctext(d, W // 2, 176, "THE CHANNEL CHANGELOG — A REPORT, NOT AN AD",
                  FB(28), (196, 201, 216), 1)
    # ---- rows: comment lands, then flips into the change ----
    fl = flips()
    for i, (handle, text, initial, change, label, target, suffix) in enumerate(ROWS):
        land = s1 + 0.45 + i * 0.55
        if t < land:
            continue
        lp = ease_out(min((t - land) / 0.4, 1.0))
        y = ROW_Y[i] - int((1 - lp) * 40)
        x = W // 2 - CW // 2
        ft = fl[i]
        if t < ft:
            card = comment_card(handle, text, initial)
            img.paste(card, (x, y), card)
        else:
            fp = min((t - ft) / 0.55, 1.0)
            num = count_up(target, t - ft - 0.28, 0.7)
            chg = change_card(change, label, num, suffix)
            if fp < 0.5:
                sq = max(int(CW * (1 - fp * 2 * 0.92)), 8)
                old = comment_card(handle, text, initial).resize((sq, CH), Image.LANCZOS)
                img.paste(old, (W // 2 - sq // 2, y), old)
            elif fp < 1.0:
                sq = max(int(CW * ((fp - 0.5) * 2 * 0.92 + 0.08)), 8)
                new = chg.resize((sq, CH), Image.LANCZOS)
                img.paste(new, (W // 2 - sq // 2, y), new)
            else:
                img.paste(chg, (x, y), chg)
        d = ImageDraw.Draw(img, "RGBA")
    return img

def tighten(tag):
    """House TP discipline: if the master measures above -1.5 dBTP, trim the
    audio by the excess and re-limit (the s52 'TP-tightening pass')."""
    master = os.path.join(HERE, f"{tag}.mp4")
    q = pc.qc(master, tag)
    if q["tp"] > -1.5:
        gain = -1.55 - q["tp"]
        tmp = os.path.join(HERE, f"{tag}_tp.mp4")
        pc.run(f"ffmpeg -y -loglevel error -i {master} -af volume={gain:.2f}dB,"
               f"alimiter=limit=0.80:level=false -c:v copy -c:a aac -b:a 160k "
               f"-movflags +faststart {tmp}")
        os.replace(tmp, master)
        review = os.path.join(HERE, f"{tag}_review.mp4")
        pc.run(f"ffmpeg -y -loglevel error -i {master} -c:v libx264 -profile:v main -crf 26 "
               f"-preset veryfast -pix_fmt yuv420p -c:a aac -b:a 128k -movflags +faststart {review}")
        q = pc.qc(master, tag)
        print(f"{tag} TP-tightened by {gain:.2f} dB -> LUFS={q['lufs']:.2f} TP={q['tp']:.2f}")
    return q

def main():
    global STARTS, VO_END
    vo = synth_vo(LINES, TAG)
    STARTS, VO_END = _compute(vo["durs"])
    starts = STARTS
    total = VO_END + 0.95
    caps = Caps()
    for s, dur, (txt, hot) in zip(starts, vo["durs"], CAPS):
        caps.add(s, s + dur + 0.25, txt, hot)
    fl = flips()
    sfx = [("hit", 0.2, 0.85)]
    sfx += [("click", starts[0] + 0.45 + i * 0.55 + 0.3, 0.55) for i in range(3)]
    sfx += [("whoosh", f, 0.6) for f in fl]
    sfx += [("click", f + 0.55, 0.7) for f in fl]
    audio = build_track(total, vo["arrays"], starts, seed=71, sfx=sfx)

    def full(t):
        img = draw(t)
        caps.draw(img, t)
        return img

    finish(TAG, total, full, audio)
    q = tighten(TAG)
    print(TAG, "starts", [round(s, 2) for s in starts], "flips", [round(f, 2) for f in fl],
          "total", round(total, 2), "QC", q)

if __name__ == "__main__":
    main()
