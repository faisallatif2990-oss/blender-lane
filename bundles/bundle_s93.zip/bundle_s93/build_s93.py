# -*- coding: utf-8 -*-
"""Skill #93 — The denial-vs-deeds refrain.
Route: motionmaxxing — refrain card choreography, CPU. Fresh
original showcase: the denial is quoted once, in full, and pinned
at the top of the frame — "NO WATER SHORTAGE." — THE COMMISSIONER,
ON CAMERA. Beneath it, the denier's own dated deeds slap in one by
one — 7 MARCH: TANKER PRICES DOUBLED · 8 MARCH: WATER SUPPLY
HALVED · 9 MARCH: NEW BOREWELLS BANNED — and every deed is closed
by the SAME unvaried question, typed out word for word three
times: "IF THERE IS NO SHORTAGE — WHY?" The monotony is the
force; the audience delivers the verdict by the third repetition.
English on-screen text, locked Hindi VO (tts speed 95, natural
speed, pre-generated in this bundle), clean small captions with
gold hot-words, -14 LUFS master.
Lane needs: python3 + Pillow + numpy, ffmpeg. No network, no tts.
"""
import os, sys, math, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "house"))
from PIL import Image, ImageDraw, ImageFilter, ImageChops
import numpy as np
import proto_common as pc
from proto_common import (W, H, F, tw, ctext, ease_out, ease_inout, GOLD,
                          WHITE, Caps, synth_vo, layout, build_track,
                          finish, solid, vignette_l)
from lab_common import FB, FS, FSB, FM, FMB

pc.LAB = HERE
TAG = "s93"
RED = (205, 52, 40)
CARD = (26, 29, 44)
CARD_E = (58, 63, 84)
SLATE = (170, 178, 196)
QUESTION = "IF THERE IS NO SHORTAGE — WHY?"
DEEDS = [("7 MARCH", "TANKER PRICES DOUBLED"),
         ("8 MARCH", "WATER SUPPLY HALVED"),
         ("9 MARCH", "NEW BOREWELLS BANNED")]
ROW_Y = [300, 505, 710]

LINES = [
    # EN: The commissioner said — there is no shortage of water.
    "आयुक्त बोले — पानी की कोई कमी नहीं है।",
    # EN: 7 March — tanker prices doubled. If there is no shortage, then why?
    "सात मार्च — टैंकरों के दाम दोगुने। कमी नहीं है, तो क्यों?",
    # EN: 8 March — the water was halved. 9 March — new borewells banned. If there is no shortage, then why?
    "आठ मार्च — पानी आधा कर दिया गया। नौ मार्च — नए बोरवेल बंद। कमी नहीं है, तो क्यों?",
]
CAPS = [
    ("The COMMISSIONER: 'No water shortage.'", "COMMISSIONER"),
    ("7 MARCH — tanker prices DOUBLED. No shortage? Why?", "DOUBLED"),
    ("8 MARCH — supply HALVED. 9 MARCH — borewells banned. Why?", "HALVED"),
]

def backdrop():
    img = solid((14, 16, 30))
    glow = Image.new("RGB", (W, H), (0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse([W // 2 - 780, 40, W // 2 + 780, 880], fill=(36, 34, 70))
    glow = glow.filter(ImageFilter.GaussianBlur(180))
    img = ImageChops.add(img, glow)
    d = ImageDraw.Draw(img, "RGBA")
    for gx in range(90, W - 60, 60):
        for gy in range(70, H - 60, 60):
            d.ellipse([gx, gy, gx + 3, gy + 3], fill=(150, 150, 210, 22))
    return vignette_l(img)

BACK = backdrop()

def _compute(durs):
    starts, vo_end = layout(durs, gap=0.30)
    return starts, vo_end

try:
    _durs0 = json.load(open(os.path.join(HERE, f"{TAG}_vo.json")))["durs"]
except Exception:
    _durs0 = [2.8, 3.9, 6.9]
STARTS, VO_END = _compute(_durs0)

def row_times():
    s1, s2, s3 = STARTS
    deeds = [s2 + 0.10, s3 + 0.15, s3 + 2.60]
    quests = [s2 + 0.80, s3 + 0.85, s3 + 3.30]
    return deeds, quests

def draw(t):
    s1, s2, s3 = STARTS
    img = BACK.copy()
    d = ImageDraw.Draw(img, "RGBA")
    # ---- the denial, pinned at the top (line 1) ----
    pin = ease_out(min(max((t - 0.25) / 0.5, 0.0), 1.0))
    mv = ease_inout(min(max((t - s2) / 0.5, 0.0), 1.0))
    dw = int(900 - 100 * mv); dh = int(160 - 30 * mv)
    dx, dy = W // 2 - dw // 2, int(84 - 14 * mv) + int((1 - pin) * 40)
    if pin > 0:
        d.rounded_rectangle([dx, dy, dx + dw, dy + dh], radius=14, fill=(18, 20, 32, 245),
                            outline=RED + (255,), width=3)
        ctext(d, W // 2, dy + int(26 - 6 * mv), '"NO WATER SHORTAGE."',
              F(int(58 - 8 * mv)), WHITE, 1)
        ctext(d, W // 2, dy + int(102 - 18 * mv), "— THE COMMISSIONER, ON CAMERA",
              FM(int(25 - 2 * mv)), SLATE, 0)
    # ---- deed rows + the unvaried refrain ----
    deeds_t, quests_t = row_times()
    for i, (date, deed) in enumerate(DEEDS):
        ry = ROW_Y[i]
        dt = deeds_t[i]
        if t >= dt:
            p = ease_out(min((t - dt) / 0.3, 1.0))
            cw2, ch2 = int(780 * (1.14 - 0.14 * p)), int(180 * (1.14 - 0.14 * p))
            cx, cy = 120 + 390, ry + 90
            card = Image.new("RGBA", (cw2, ch2), (0, 0, 0, 0))
            cd = ImageDraw.Draw(card)
            cd.rounded_rectangle([3, 3, cw2 - 3, ch2 - 3], radius=14, fill=CARD + (255,),
                                 outline=CARD_E + (255,), width=3)
            fs1 = int(30 * (1.14 - 0.14 * p)); fs2 = int(41 * (1.14 - 0.14 * p))
            cd.text((int(30 * (1.14 - 0.14 * p)), int(22 * (1.14 - 0.14 * p))), date,
                    font=FM(fs1), fill=GOLD + (255,))
            cd.text((int(30 * (1.14 - 0.14 * p)), int(76 * (1.14 - 0.14 * p))), deed,
                    font=FB(fs2), fill=WHITE + (255,))
            img.paste(card, (cx - cw2 // 2, cy - ch2 // 2), card)
            d = ImageDraw.Draw(img, "RGBA")
        qt = quests_t[i]
        if t >= qt:
            nch = len(QUESTION)
            shown = int(nch * min(max((t - qt) / 1.05, 0.0), 1.0))
            txt = QUESTION[:shown]
            if txt:
                d.text((950, ry + 62), txt, font=FB(37), fill=GOLD + (255,))
            if shown < nch or (t * 2) % 1 < 0.6:
                cw3, _ = tw(d, txt, FB(37), 0)
                d.rectangle([950 + cw3 + 8, ry + 66, 950 + cw3 + 28, ry + 104],
                            fill=GOLD + (220,))
    return img

def tighten(tag):
    """House TP discipline: if the master measures above -1.5 dBTP, trim the
    audio by the excess and re-limit (the s52 'TP-tightening pass')."""
    master = os.path.join(HERE, f"{tag}.mp4")
    q = pc.qc(master, tag)
    if q["tp"] > -1.5:
        gain = -1.55 - q["tp"]
        tmp = os.path.join(HERE, f"{tag}_tp.mp4")
        pc.run(f"ffmpeg -y -loglevel error -i {master} -af volume={gain:.2f}dB,"
               f"alimiter=limit=0.80:level=false -c:v copy -c:a aac -b:a 160k "
               f"-movflags +faststart {tmp}")
        os.replace(tmp, master)
        review = os.path.join(HERE, f"{tag}_review.mp4")
        pc.run(f"ffmpeg -y -loglevel error -i {master} -c:v libx264 -profile:v main -crf 26 "
               f"-preset veryfast -pix_fmt yuv420p -c:a aac -b:a 128k -movflags +faststart {review}")
        q = pc.qc(master, tag)
        print(f"{tag} TP-tightened by {gain:.2f} dB -> LUFS={q['lufs']:.2f} TP={q['tp']:.2f}")
    return q

def main():
    global STARTS, VO_END
    vo = synth_vo(LINES, TAG)
    STARTS, VO_END = _compute(vo["durs"])
    starts = STARTS
    total = VO_END + 0.95
    caps = Caps()
    for s, dur, (txt, hot) in zip(starts, vo["durs"], CAPS):
        caps.add(s, s + dur + 0.25, txt, hot)
    deeds_t, quests_t = row_times()
    sfx = [("hit", 0.25, 0.9)]
    for dt in deeds_t:
        sfx.append(("hit", dt, 0.85))
    for qt in quests_t:
        sfx += [("click", qt + 0.25, 0.35), ("click", qt + 0.6, 0.35),
                ("click", qt + 0.95, 0.35)]
    audio = build_track(total, vo["arrays"], starts, seed=93,
                        music_freqs=(55.0, 82.4, 110.0), sfx=sfx)

    def full(t):
        img = draw(t)
        caps.draw(img, t)
        return img

    finish(TAG, total, full, audio)
    q = tighten(TAG)
    print(TAG, "starts", [round(s, 2) for s in starts], "total", round(total, 2), "QC", q)

if __name__ == "__main__":
    main()
