# -*- coding: utf-8 -*-
"""Skill #78 — The participant dispatch.
Route: plain route — real-footage edit (field address over real event
footage), CPU. Weakest-fit skill of the 55 for a faceless channel, built
in field-footage form as ordered: the voice addresses the square
directly over REAL crowd footage of a real historic gathering
(assets/crowd_s78.mp4 — a 1945 V-J Day crowd, Prelinger, public domain;
see assets/CREDIT.txt), numbered demand cards land at the SIDE of the
frame, and a closing card sets the next gathering's date and place.
English on-screen text, locked Hindi VO (tts speed 95, natural speed,
pre-generated in this bundle), clean small captions with gold
hot-words, -14 LUFS master.
Lane needs: python3 + Pillow + numpy, ffmpeg. No network, no tts.
"""
import os, sys, math, json, subprocess
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "house"))
from PIL import Image, ImageDraw, ImageFilter
import numpy as np
import proto_common as pc
from proto_common import (W, H, F, tw, ctext, ease_out, ease_inout, GOLD,
                          WHITE, Caps, synth_vo, layout, build_track,
                          finish, vignette_l, grade_v2)
from lab_common import FB, FS, FSB, FM, FMB

pc.LAB = HERE
TAG = "s78"
ASSET = os.path.join(HERE, "assets", "crowd_s78.mp4")
DEMANDS = ["OPEN THE RECORDS", "COUNT EVERY NAME", "ANSWER IN PUBLIC"]

LINES = [
    # EN: I am not speaking from a studio — I am standing in this very square.
    "मैं स्टूडियो से नहीं बोल रहा — मैं इसी चौक में खड़ा हूँ।",
    # EN: Three demands — open the records, count every name, answer in public.
    "तीन माँगें हैं — अभिलेख खोलो, हर नाम गिनो, जवाब सबके सामने दो।",
    # EN: The next gathering — in this square, on 26 January.
    "अगली सभा — इसी चौक में, छब्बीस जनवरी को।",
]
CAPS = [
    ("Not the studio — I am STANDING in this square", "STANDING"),
    ("THREE demands — records open, names counted, answers public", "THREE"),
    ("NEXT gathering — this square — 26 January", "NEXT"),
]

class Grabber:
    """Sequential reader over the crowd footage at output size."""
    def __init__(self, path, start_s=1.0):
        cmd = (f"ffmpeg -v error -ss {start_s} -i {path} -vf "
               f"scale=1920:1440:flags=lanczos,crop=1920:1080:0:180,fps=24 "
               f"-f rawvideo -pix_fmt rgb24 -")
        self.pr = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        self.idx = -1; self.cur = None; self.n = W * H * 3
    def frame(self, i):
        while self.idx < i:
            buf = self.pr.stdout.read(self.n)
            if len(buf) < self.n:
                break
            self.cur = Image.frombytes("RGB", (W, H), buf)
            self.idx += 1
        return self.cur

GRAB = None

def _compute(durs):
    starts, vo_end = layout(durs, gap=0.30)
    return starts, vo_end

try:
    _durs0 = json.load(open(os.path.join(HERE, f"{TAG}_vo.json")))["durs"]
except Exception:
    _durs0 = [3.2, 3.8, 2.6]
STARTS, VO_END = _compute(_durs0)

def draw(t):
    global GRAB
    s1, s2, s3 = STARTS
    total = VO_END + 0.95
    if GRAB is None:
        GRAB = Grabber(ASSET)
    raw = GRAB.frame(int(t * 24))
    if raw is None:
        raw = Image.new("RGB", (W, H), (24, 24, 24))
    # slow push-in over the whole clip (the field camera breathes forward)
    z = 1.0 + 0.10 * ease_inout(min(t / total, 1.0))
    cw, ch = int(W / z), int(H / z)
    x0 = (W - cw) // 2; y0 = int((H - ch) * 0.44)
    img = raw.crop((x0, y0, x0 + cw, y0 + ch)).resize((W, H), Image.LANCZOS)
    img = grade_v2(img)
    img = vignette_l(img)
    d = ImageDraw.Draw(img, "RGBA")
    # ---- location + credit chips ----
    pc.date_chip(d, "ON THE GROUND — THE OLD SQUARE")
    cred = "FIELD FOOTAGE: 1945 CROWD (PUBLIC DOMAIN)"
    f = FM(22); wpx, bb = tw(d, cred, f, 3)
    d.rounded_rectangle([W - wpx - 84, 96, W - 42, 96 + 44], radius=8, fill=(0, 0, 0, 170))
    d.text((W - wpx - 63 - bb[0], 96 + 8 - bb[1]), cred, font=f, fill=(225, 228, 238, 255),
           stroke_width=3, stroke_fill=(0, 0, 0, 220))
    # ---- demand cards land at the RIGHT side during line 2 ----
    for i, dem in enumerate(DEMANDS):
        ct = s2 + 0.30 + i * 0.85
        if t < ct:
            continue
        p = ease_out(min((t - ct) / 0.42, 1.0))
        cw2, ch2 = 600, 118
        bx = int(W - 56 - cw2 + (1 - p) * 700)
        by = 268 + i * 148
        d.rounded_rectangle([bx, by, bx + cw2, by + ch2], radius=14,
                            fill=(10, 12, 18, 225), outline=GOLD + (255,), width=2)
        d.ellipse([bx + 22, by + 28, bx + 84, by + 90], fill=GOLD + (255,))
        ctext(d, bx + 53, by + 38, str(i + 1), F(44), (12, 12, 14), 0)
        d.text((bx + 108, by + 40), dem, font=FB(36), fill=WHITE + (255,))
    # ---- closing card (line 3): next gathering, bottom-left ----
    if t > s3 + 0.30:
        p = ease_out(min((t - s3 - 0.30) / 0.45, 1.0))
        bw, bh = 660, 116
        bx = int(64 - (1 - p) * 500); by = 780
        d.rounded_rectangle([bx, by, bx + bw, by + bh], radius=14,
                            fill=(12, 14, 22, 235), outline=GOLD + (255,), width=2)
        if p > 0.55:
            d.text((bx + 28, by + 16), "NEXT GATHERING", font=F(30), fill=GOLD + (255,))
            d.text((bx + 28, by + 60), "THIS SQUARE — 26 JANUARY", font=FB(31),
                   fill=WHITE + (255,))
    return img

def tighten(tag):
    """House TP discipline: if the master measures above -1.5 dBTP, trim the
    audio by the excess and re-limit (the s52 'TP-tightening pass')."""
    master = os.path.join(HERE, f"{tag}.mp4")
    q = pc.qc(master, tag)
    if q["tp"] > -1.5:
        gain = -1.55 - q["tp"]
        tmp = os.path.join(HERE, f"{tag}_tp.mp4")
        pc.run(f"ffmpeg -y -loglevel error -i {master} -af volume={gain:.2f}dB,"
               f"alimiter=limit=0.80:level=false -c:v copy -c:a aac -b:a 160k "
               f"-movflags +faststart {tmp}")
        os.replace(tmp, master)
        review = os.path.join(HERE, f"{tag}_review.mp4")
        pc.run(f"ffmpeg -y -loglevel error -i {master} -c:v libx264 -profile:v main -crf 26 "
               f"-preset veryfast -pix_fmt yuv420p -c:a aac -b:a 128k -movflags +faststart {review}")
        q = pc.qc(master, tag)
        print(f"{tag} TP-tightened by {gain:.2f} dB -> LUFS={q['lufs']:.2f} TP={q['tp']:.2f}")
    return q

def main():
    global STARTS, VO_END
    vo = synth_vo(LINES, TAG)
    STARTS, VO_END = _compute(vo["durs"])
    starts = STARTS
    total = VO_END + 0.95
    caps = Caps()
    for s, dur, (txt, hot) in zip(starts, vo["durs"], CAPS):
        caps.add(s, s + dur + 0.25, txt, hot)
    s2 = starts[1]
    sfx = [("whoosh", 0.05, 0.5)]
    sfx += [("hit", s2 + 0.30 + i * 0.85, 0.75) for i in range(3)]
    sfx += [("hit", starts[2] + 0.30, 0.9)]
    audio = build_track(total, vo["arrays"], starts, seed=41, sfx=sfx)

    def full(t):
        img = draw(t)
        caps.draw(img, t)
        return img

    finish(TAG, total, full, audio)
    q = tighten(TAG)
    print(TAG, "starts", [round(s, 2) for s in starts], "total", round(total, 2), "QC", q)

if __name__ == "__main__":
    main()
