# -*- coding: utf-8 -*-
"""Skill #86 — The AI panel.
Route: 99-style 67 — Dark Tech Keynote (lemo-opuscar), CPU. Fresh
original showcase in the style grammar: near-black UI, ONE accent
(cyan), soft light. One plain common-sense question is typed in —
"THE BRIDGE REPORT SHOWS CRACKS. PUBLISH IT — OR BURY IT?" — then
six chat panels bloom in a row (CHATGPT / GEMINI / DEEPSEEK /
PERPLEXITY / CLAUDE / GROK), each answering "PUBLISH IT", a counter
ticks to 6 / 6, and the judgement is handed back to the viewer:
"NOW JUDGE IT YOURSELF". English on-screen text, locked Hindi VO
(tts speed 95, natural speed, pre-generated in this bundle), clean
small captions with gold hot-words, -14 LUFS master.
Lane needs: python3 + Pillow + numpy, ffmpeg. No network, no tts.
"""
import os, sys, math, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "house"))
from PIL import Image, ImageDraw, ImageFilter, ImageChops
import numpy as np
import proto_common as pc
from proto_common import (W, H, F, tw, ctext, ease_out, ease_inout, GOLD,
                          WHITE, Caps, synth_vo, layout, build_track,
                          finish, solid, vignette_l)
from lab_common import FB, FS, FSB, FM, FMB

pc.LAB = HERE
TAG = "s86"
ACC = (92, 204, 255)          # the style's ONE accent
SLATE = (148, 160, 178)
PANEL = (16, 20, 28)
PANEL_E = (46, 58, 76)
NAMES = ["CHATGPT", "GEMINI", "DEEPSEEK", "PERPLEXITY", "CLAUDE", "GROK"]
QUESTION = ["THE BRIDGE REPORT SHOWS CRACKS.", "PUBLISH IT — OR BURY IT?"]
HEADLINE = "ONE PLAIN QUESTION"

LINES = [
    # EN: A plain question — asked to every big AI.
    "एक सीधा सवाल — हर बड़े एआई से पूछा गया।",
    # EN: The question was — should the bridge report be published, or buried?
    "सवाल था — पुल की रिपोर्ट छपे, या दबा दी जाए?",
    # EN: All six said — publish it. Now the judgement is yours.
    "छह के छह बोले — छापो। अब फ़ैसला आपका है।",
]
CAPS = [
    ("A plain QUESTION — asked to every big AI", "QUESTION"),
    ("Publish the bridge REPORT — or bury it?", "REPORT"),
    ("SIX of six said PUBLISH — the verdict is yours", "PUBLISH"),
]

def backdrop():
    img = solid((7, 9, 13))
    glow = Image.new("RGB", (W, H), (0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse([W // 2 - 700, -260, W // 2 + 700, 560], fill=(16, 30, 44))
    glow = glow.filter(ImageFilter.GaussianBlur(170))
    img = ImageChops.add(img, glow)
    return vignette_l(img)

BACK = backdrop()

def _compute(durs):
    starts, vo_end = layout(durs, gap=0.30)
    return starts, vo_end

try:
    _durs0 = json.load(open(os.path.join(HERE, f"{TAG}_vo.json")))["durs"]
except Exception:
    _durs0 = [3.2, 3.6, 3.4]
STARTS, VO_END = _compute(_durs0)
DURS = _durs0

def panel_img(name, answered):
    w, h = 292, 300
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([3, 3, w - 3, h - 3], radius=18, fill=PANEL + (255,),
                        outline=PANEL_E + (255,), width=2)
    ctext(d, w // 2, 30, name, FM(27), SLATE + (255,), 0)
    d.rounded_rectangle([46, 92, w - 46, 168], radius=14, outline=ACC + (200,), width=3)
    d.polygon([(70, 168), (70, 196), (98, 168)], fill=PANEL + (255,), outline=ACC + (200,))
    if answered:
        ctext(d, w // 2, 112, "PUBLISH IT", FB(34), ACC + (255,), 0)
    else:
        ctext(d, w // 2, 112, "· · ·", FB(34), SLATE + (255,), 0)
    ctext(d, w // 2, 226, "ANSWERED", FM(22), SLATE + (160,) if answered else (0, 0, 0, 0), 0)
    return img

PANELS_OFF = [panel_img(n, False) for n in NAMES]
PANELS_ON = [panel_img(n, True) for n in NAMES]

def draw(t):
    s1, s2, s3 = STARTS
    img = BACK.copy()
    d = ImageDraw.Draw(img, "RGBA")
    d.text((70, 58), "THE AI PANEL", font=FM(30), fill=SLATE + (220,))
    # ---- counter (top-right) ----
    landed = 0
    for i in range(6):
        if t >= s3 + i * 0.28 + 0.30:
            landed += 1
    ccol = GOLD if landed == 6 else ACC
    ctxt = f"{landed} / 6"
    w, _bb = tw(d, ctxt, FM(46), 0)
    d.text((W - 70 - w, 48), ctxt, font=FM(46), fill=ccol + (255,))
    # ---- headline: per-character pop (line 1) ----
    f = F(84)
    widths = [tw(d, ch, f, 2)[0] for ch in HEADLINE]
    total_w = sum(widths) + 8 * (len(HEADLINE) - 1)
    x = (W - total_w) // 2
    for i, ch in enumerate(HEADLINE):
        ct = 0.15 + i * 0.045
        p = ease_out(min(max((t - ct) / 0.22, 0.0), 1.0))
        if p > 0:
            fs = int(84 * (0.6 + 0.4 * p)) if p < 1 else 84
            ff = F(fs)
            bb = d.textbbox((0, 0), ch, font=ff, stroke_width=2)
            d.text((x - bb[0], 138 - bb[1] - int(10 * (1 - p))), ch, font=ff,
                   fill=WHITE + (int(255 * p),), stroke_width=2, stroke_fill=(0, 0, 0, 120))
        x += widths[i] + 8
    up = ease_out(min(max((t - 1.15) / 0.7, 0.0), 1.0))
    if up > 0:
        d.line([W // 2 - int(430 * up), 262, W // 2 + int(430 * up), 262],
               fill=ACC + (220,), width=4)
    if t > 1.35:
        ctext(d, W // 2, 284, "ASKED TO EVERY MAJOR AI — ON CAMERA", FM(29), SLATE, 0)
    # ---- the question types in (line 2) ----
    if t >= s2:
        d.rounded_rectangle([260, 356, 1660, 516], radius=16, fill=(13, 17, 24, 235),
                            outline=ACC + (170,), width=2)
        full = QUESTION[0] + "\n" + QUESTION[1]
        nch = len(full)
        shown = int(nch * min(max((t - s2 - 0.15) / (DURS[1] * 0.88), 0.0), 1.0))
        txt = full[:shown]
        parts = txt.split("\n")
        for j, ln in enumerate(parts):
            if ln:
                d.text((310, 388 + j * 62), ln, font=FB(43), fill=WHITE + (255,))
        # accent cursor block
        if shown < nch or (t * 2) % 1 < 0.6:
            last = parts[-1] if parts else ""
            cw, _ = tw(d, last, FB(43), 0)
            cx = 310 + cw + 10
            cy = 392 + (len(parts) - 1) * 62
            d.rectangle([cx, cy, cx + 22, cy + 46], fill=ACC + (230,))
    # ---- six panels bloom (line 3) ----
    for i in range(6):
        pt = s3 + i * 0.28
        if t < pt:
            continue
        p = ease_out(min((t - pt) / 0.38, 1.0))
        answered = t >= pt + 0.30
        pim = PANELS_ON[i] if answered else PANELS_OFF[i]
        sc = 0.82 + 0.18 * p
        w2, h2 = int(292 * sc), int(300 * sc)
        pim2 = pim.resize((w2, h2), Image.LANCZOS)
        if p < 1:
            a = pim2.split()[3].point(lambda v: int(v * p))
            pim2.putalpha(a)
        x0 = 44 + i * (292 + 16) + (292 - w2) // 2
        y0 = 600 + (300 - h2) // 2
        img.paste(pim2, (x0, y0), pim2)
        d = ImageDraw.Draw(img, "RGBA")
    # ---- judgement handed back ----
    if t >= s3 + 6 * 0.28 + 0.55:
        ctext(d, W // 2, 540, "NOW JUDGE IT YOURSELF", F(45), WHITE, 2)
    return img

def tighten(tag):
    """House TP discipline: if the master measures above -1.5 dBTP, trim the
    audio by the excess and re-limit (the s52 'TP-tightening pass')."""
    master = os.path.join(HERE, f"{tag}.mp4")
    q = pc.qc(master, tag)
    if q["tp"] > -1.5:
        gain = -1.55 - q["tp"]
        tmp = os.path.join(HERE, f"{tag}_tp.mp4")
        pc.run(f"ffmpeg -y -loglevel error -i {master} -af volume={gain:.2f}dB,"
               f"alimiter=limit=0.80:level=false -c:v copy -c:a aac -b:a 160k "
               f"-movflags +faststart {tmp}")
        os.replace(tmp, master)
        review = os.path.join(HERE, f"{tag}_review.mp4")
        pc.run(f"ffmpeg -y -loglevel error -i {master} -c:v libx264 -profile:v main -crf 26 "
               f"-preset veryfast -pix_fmt yuv420p -c:a aac -b:a 128k -movflags +faststart {review}")
        q = pc.qc(master, tag)
        print(f"{tag} TP-tightened by {gain:.2f} dB -> LUFS={q['lufs']:.2f} TP={q['tp']:.2f}")
    return q

def main():
    global STARTS, VO_END, DURS
    vo = synth_vo(LINES, TAG)
    DURS = vo["durs"]
    STARTS, VO_END = _compute(DURS)
    starts = STARTS
    total = VO_END + 0.95
    caps = Caps()
    for s, dur, (txt, hot) in zip(starts, DURS, CAPS):
        caps.add(s, s + dur + 0.25, txt, hot)
    sfx = [("whoosh", starts[1], 0.5)]
    sfx += [("click", starts[2] + i * 0.28 + 0.3, 0.6) for i in range(6)]
    sfx += [("hit", starts[2] + 5 * 0.28 + 0.32, 0.9)]
    audio = build_track(total, vo["arrays"], starts, seed=86,
                        music_freqs=(55.0, 110.0, 164.8), sfx=sfx)

    def full(t):
        img = draw(t)
        caps.draw(img, t)
        return img

    finish(TAG, total, full, audio)
    q = tighten(TAG)
    print(TAG, "starts", [round(s, 2) for s in starts], "total", round(total, 2), "QC", q)

if __name__ == "__main__":
    main()
