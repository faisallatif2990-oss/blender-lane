# -*- coding: utf-8 -*-
"""Skill #80 — The adaptation refutation.
Route: manim-skill — precise diagram (response-curve decay), CPU. Fresh
original showcase: a tonic's mechanism taught fairly — the dose works,
fully, on day one — then the body's own adaptation expires it: seven
daily dose bars at full height, the response curve answering lower
every time, until the last dose fires and nothing rises: "THE BODY
ADAPTS". Integration mirrors bundle_s72 exactly: locked Hindi VO is
synthesised FIRST (proto_common.synth_vo, tts --language hi --speed 95,
natural speed, NEVER atempo); the layout goes to s80_timing.json; the
Manim scene (scene_s80.py, Pango Text only) renders SILENT at
1920x1080/24fps sized to the spoken beats; the build composites house
Caps per frame, builds the VO track with proto_common.build_track, and
encodes / loudnorms through proto_common.encode (-14 LUFS) + the house
tighten() TP pass. Review copy produced alongside.
Lane needs: python3 + Pillow + numpy, ffmpeg/ffprobe, AND Manim CE —
the house venv at ~/workspace/tools/manim-venv, or `pip install manim`
with system cairo/pango. VO is pre-generated in this bundle
(s80_vo_*.mp3) — no tts, no network needed for the voice.
"""
import json, os, shutil, subprocess, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "house"))
from PIL import Image
import proto_common as pc
from proto_common import W, H, FPS, Caps, synth_vo, layout, build_track

pc.LAB = HERE
TAG = "s80"

LINES = [
    # EN: The medicine truly works — day one, full effect.
    "दवा सच में काम करती है — पहला दिन, पूरा असर।",
    # EN: But the body learns — every dose answered less than before.
    "पर शरीर सीखता है — हर खुराक का जवाब पहले से कम।",
    # EN: The last dose — and no response. The body has adapted.
    "आख़िरी खुराक — और कोई जवाब नहीं। शरीर ढल गया।",
]
CAPS = [
    ("The medicine WORKS — day one, full effect", "WORKS"),
    ("The body LEARNS — each dose, a smaller answer", "LEARNS"),
    ("The last dose — NO answer. The body adapts", "NO"),
]


def manim_bin():
    env = os.environ.get("MANIM_BIN")
    if env and os.path.exists(env):
        return env
    venv = os.path.expanduser("~/workspace/tools/manim-venv/bin/manim")
    if os.path.exists(venv):
        return venv
    found = shutil.which("manim")
    if found:
        return found
    print("MISSING: Manim CE — install the house venv "
          "(~/workspace/tools/manim-venv) or `pip install manim` "
          "(needs system cairo + pango) so a manim binary exists.")
    sys.exit(1)


def render_manim():
    media = os.path.join(HERE, "_manim_media")
    cmd = (f"{manim_bin()} render --resolution 1920,1080 --fps {FPS} "
           f"--media_dir {media} "
           f"{os.path.join(HERE, 'scene_s80.py')} ResponseCurve")
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if r.returncode != 0:
        print("MANIM RENDER FAILED"); print((r.stdout + r.stderr)[-2000:])
        sys.exit(1)
    for root, _dirs, files in os.walk(media):
        for f in files:
            if f == "ResponseCurve.mp4":
                return os.path.join(root, f)
    print("MANIM OUTPUT NOT FOUND under", media); sys.exit(1)


def manim_frames(silent_mp4, total):
    """Yield exactly int(total*FPS) PIL frames from the silent render,
    Caps drawn per frame (house way). Pads with the last frame / trims
    if the render is a frame or two off the VO total."""
    caps = Caps()
    vo = synth_vo(LINES, TAG)  # cached — durations only, no re-synth
    starts, _ = layout(vo["durs"], gap=0.30)
    for s, dur, (txt, hot) in zip(starts, vo["durs"], CAPS):
        caps.add(s, s + dur + 0.25, txt, hot)
    n_frames = int(total * FPS)
    frame_bytes = W * H * 3
    proc = subprocess.Popen(
        f"ffmpeg -y -loglevel error -i {silent_mp4} -f rawvideo "
        f"-pix_fmt rgb24 -s {W}x{H} -r {FPS} -",
        shell=True, stdout=subprocess.PIPE)
    last = None
    for i in range(n_frames):
        raw = proc.stdout.read(frame_bytes)
        if raw and len(raw) == frame_bytes:
            last = Image.frombytes("RGB", (W, H), raw)
        if last is None:
            img = Image.new("RGB", (W, H), (15, 17, 34))
        else:
            img = last.copy()
        caps.draw(img, i / FPS)
        yield img
    proc.stdout.close()
    proc.terminate()


def tighten(tag):
    """House TP discipline: if the master measures above -1.5 dBTP, trim
    the audio by the excess and re-limit (the s52 'TP-tightening pass')."""
    master = os.path.join(HERE, f"{tag}.mp4")
    q = pc.qc(master, tag)
    if q["tp"] > -1.5:
        gain = -1.55 - q["tp"]
        tmp = os.path.join(HERE, f"{tag}_tp.mp4")
        pc.run(f"ffmpeg -y -loglevel error -i {master} -af volume={gain:.2f}dB,"
               f"alimiter=limit=0.80:level=false -c:v copy -c:a aac -b:a 160k "
               f"-movflags +faststart {tmp}")
        os.replace(tmp, master)
        review = os.path.join(HERE, f"{tag}_review.mp4")
        pc.run(f"ffmpeg -y -loglevel error -i {master} -c:v libx264 -profile:v main "
               f"-crf 26 -preset veryfast -pix_fmt yuv420p -c:a aac -b:a 128k "
               f"-movflags +faststart {review}")
        q = pc.qc(master, tag)
        print(f"{tag} TP-tightened by {gain:.2f} dB -> LUFS={q['lufs']:.2f} TP={q['tp']:.2f}")
    return q


def main():
    vo = synth_vo(LINES, TAG)
    starts, vo_end = layout(vo["durs"], gap=0.30)
    total = vo_end + 0.95
    s1, s2, s3 = starts
    with open(os.path.join(HERE, "s80_timing.json"), "w") as fh:
        json.dump({"lines": LINES, "durs": vo["durs"],
                   "starts": starts, "total": total}, fh, ensure_ascii=False)

    silent = render_manim()
    print("manim silent render:", silent)

    step = (s3 - s2) / 5.0
    sfx = [("click", s2 + step * i, 0.65) for i in range(1, 6)]
    sfx += [("click", s3 + 0.45, 0.7), ("hit", s3 + 1.35, 0.95),
            ("whoosh", s3, 0.5)]
    audio = build_track(total, vo["arrays"], starts, seed=29, sfx=sfx)

    master, review = pc.encode(manim_frames(silent, total), total, audio, TAG)
    q = tighten(TAG)
    print(TAG, "starts", [round(s, 2) for s in starts],
          "total", round(total, 2), "QC", q)


if __name__ == "__main__":
    main()
