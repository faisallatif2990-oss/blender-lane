#!/bin/sh
# Skill #80 — lane build: produces s80.mp4 + s80_review.mp4 in this folder.
# Needs: python3 with Pillow + numpy, ffmpeg/ffprobe on PATH, AND Manim CE
# (the house venv at ~/workspace/tools/manim-venv, or `pip install manim`
# with system cairo/pango so `manim` is on PATH). VO is pre-generated
# (s80_vo_*.mp3 in this folder) — no network, no tts needed.
set -e
cd "$(dirname "$0")"
python3 -c "import PIL, numpy" 2>/dev/null || { echo 'MISSING: python3 Pillow/numpy'; exit 1; }
command -v ffmpeg >/dev/null || { echo 'MISSING: ffmpeg'; exit 1; }
if [ -x "$HOME/workspace/tools/manim-venv/bin/manim" ]; then
  :
elif command -v manim >/dev/null 2>&1; then
  :
else
  echo 'MISSING: Manim CE — need ~/workspace/tools/manim-venv or pip install manim (system cairo/pango required)'; exit 1
fi
python3 build_s80.py
