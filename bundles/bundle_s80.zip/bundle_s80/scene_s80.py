# -*- coding: utf-8 -*-
"""Skill #80 — The adaptation refutation (Manim CE scene, SILENT render).

Route: manim-skill (precise-diagram segment). Pango `Text` only — this
VM has NO LaTeX. Colours from the 99-styles v2 palette; background is a
built palette tone, never flat black.

Showcase: the mechanism is taught fairly, then the body's adaptation
expires it. Seven daily dose bars stand at full height along a timeline
axis — the dose never changes. The response curve answers after each
dose, lower every time (amplitudes 1.00 / 0.76 / 0.56 / 0.40 / 0.28 /
0.17), until the seventh dose fires and nothing rises: the curve lies
flat and turns red — "THE BODY ADAPTS".

Timing is NOT hard-coded: build_s80.py synthesises the locked Hindi VO
first and writes s80_timing.json (starts, total); the scene sizes its
phases from it — A: line 1 (title, axes, day 1), B: line 2 (days 2-6,
five equal steps), C: line 3 (day 7, the flat line, the banner).
Fallback durations match the bundle's shipped VO (3.00 / 3.60 / 3.20,
total 10.75 s).
"""
import json, math, os
from manim import *

HERE = os.path.dirname(os.path.abspath(__file__))

BG = "#0F1122"
GOLD = "#FFCD28"
PAPER = "#F2F0E6"
SLATE = "#C9CDD6"
FAINT = "#5A6076"
TEAL = "#40B2B2"
RED = "#E5484D"

AXIS_Y = -1.55
DAY_X = [-5.45 + i * 1.62 for i in range(7)]
AMPS = [1.00, 0.76, 0.56, 0.40, 0.28, 0.17, 0.03]
PEAK = 2.45


def _timing():
    path = os.path.join(HERE, "s80_timing.json")
    try:
        with open(path) as fh:
            t = json.load(fh)
        return [float(s) for s in t["starts"]], float(t["total"])
    except Exception:
        return [0.15, 3.45, 7.35], 10.75


def response_curve(n_doses, color=TEAL):
    """One continuous response curve: a decaying hump after each dose."""
    pts = []
    for k in range(241):
        x = -6.35 + k * (12.7 / 240.0)
        y = AXIS_Y
        for i in range(n_doses):
            c = DAY_X[i] + 0.48
            y += AMPS[i] * PEAK * math.exp(-((x - c) / 0.40) ** 2)
        pts.append([x, y, 0])
    curve = VMobject(color=color, stroke_width=7)
    curve.set_points_smoothly([Vector(*p) for p in pts])
    return curve


def dose_bar(i):
    bar = Rectangle(width=0.36, height=1.05, color=GOLD,
                    fill_color=GOLD, fill_opacity=0.22, stroke_width=5)
    bar.move_to(RIGHT * DAY_X[i] + UP * (AXIS_Y + 0.545))
    lab = Text(f"D{i + 1}", font_size=27, color=FAINT)
    lab.move_to(RIGHT * DAY_X[i] + UP * (AXIS_Y - 0.48))
    return VGroup(bar, lab)


class ResponseCurve(Scene):
    def construct(self):
        self.camera.background_color = BG
        starts, total = _timing()
        s2, s3 = starts[1], starts[2]
        dur_b = s3 - s2
        dur_c = total - s3

        # ---------------- phase A: axes + day 1 -------------------------
        title = Text("THE TONIC — DOSE vs RESPONSE", font_size=42,
                     color=GOLD, weight=BOLD).move_to(UP * 3.55)
        axis = Line(LEFT * 6.45 + UP * AXIS_Y, RIGHT * 6.45 + UP * AXIS_Y,
                    color=SLATE, stroke_width=6)
        a1 = 0.70
        self.play(FadeIn(title, shift=DOWN * 0.15), Create(axis),
                  run_time=a1, rate_func=smooth)
        d1 = dose_bar(0)
        curve = response_curve(1)
        a2 = max(s2 - a1, 0.6)
        self.play(GrowFromEdge(d1, DOWN), Create(curve),
                  run_time=a2, rate_func=smooth)

        # ---------------- phase B: days 2-6, lower every time -----------
        step = dur_b / 5.0
        for i in range(1, 6):
            self.play(GrowFromEdge(dose_bar(i), DOWN),
                      Transform(curve, response_curve(i + 1)),
                      run_time=step, rate_func=smooth)

        # ---------------- phase C: day 7 — nothing rises ----------------
        c1 = 0.50
        self.play(GrowFromEdge(dose_bar(6), DOWN),
                  Transform(curve, response_curve(7)),
                  run_time=c1, rate_func=smooth)
        c2 = 0.85
        flat_red = response_curve(7, color=RED)
        self.play(Transform(curve, flat_red), run_time=c2, rate_func=smooth)
        banner_bg = RoundedRectangle(
            corner_radius=0.12, width=6.6, height=0.82,
            color=RED, fill_color="#1B1E33", fill_opacity=1.0,
            stroke_width=4).move_to(DOWN * 3.55)
        banner = Text("THE BODY ADAPTS", font_size=38, color=RED,
                      weight=BOLD).move_to(DOWN * 3.55)
        c3 = 0.90
        self.play(FadeIn(banner_bg, shift=UP * 0.12), Write(banner),
                  run_time=c3, rate_func=smooth)
        hold = dur_c - c1 - c2 - c3
        if hold > 0.05:
            self.wait(hold)
